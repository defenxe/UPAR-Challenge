"""FP32 ViT-L/14: stop after epoch 10; Mercury smoke runs stop after N updates."""
import argparse
import gc
import json
import os
import sys
import time
import traceback
import uuid
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
import torch
from solver import build_lr_scheduler
from .config import TrainConfig
from .multiscale_model import MultiScaleLocalModel, MultiScaleModelConfig
from .data import training_loaders
from .tokenizer import PromptTokenizer
from .local_validation import evaluate_local, log, KST
from .gradient_cache import optimizer_update
from .precision import assert_model_fp32, assert_optimizer_fp32
from .runtime import prepare_gpu, memory_report, GPUMonitor
from .preflight import ensure_preflight, verify_evidence
from .train_utils import (Tee, write_json, seed_all, optimizer_for, gradient_report,
                          save_epoch_state_dict, verify_epoch_state_dict, digest)

ROOT = Path(__file__).resolve().parents[1]
FINGERPRINT = '9b857234d8c640e915154fb1e299ec366cadaa2f2435f18fc78970aaac3fbe74'


def load_config(path):
    value = json.loads(Path(path).read_text())
    train = TrainConfig(**value['train'])
    model = MultiScaleModelConfig(**value['model'])
    if value['scheduler_total_epochs'] != 60 or train.num_epoch != 60 or value['training_stop_epoch'] != 10:
        raise ValueError('Require uncompressed 60-epoch scheduler and fixed stop at epoch 10')
    if train.batch_size != 32 or value['precision'] != 'FP32':
        raise ValueError('Require FP32 and effective batch 32')
    memory = value['memory']
    if memory['micro_batch_size'] not in (1,2,4) or memory['accumulation_steps'] * memory['micro_batch_size'] != 32:
        raise ValueError('Require micro batch 1/2/4 and effective batch 32')
    if value.get('gradient_clipping') is not None:
        raise ValueError('Baseline has no gradient clipping')
    if value['local_lr'] != 1e-4:
        raise ValueError('Local/MultiScale nominal LR must preserve baseline 1e-4')
    # The shipped baseline snapshot is portable and contains no runtime-only settings.
    baseline = json.loads((ROOT/'reports/baseline_config.json').read_text())
    if asdict(train) != asdict(TrainConfig(**baseline['train'])):
        raise ValueError('Train configuration differs from the original 60-epoch experiment')
    for key,val in baseline['model'].items():
        if key not in ('img_size','stride_size','multiscale_blocks') and getattr(model,key) != val and not (
                isinstance(val,list) and tuple(getattr(model,key)) == tuple(val)):
            raise ValueError('Unexpected model/loss change: '+key)
    return value,train,model


def new_run_directory(output, smoke):
    output = Path(output).resolve()
    output.mkdir(parents=True,exist_ok=True)
    path = output / ('%s_%s_KST_%s' % ('smoke' if smoke else 'train_e10',
            datetime.now(KST).strftime('%Y%m%d_%H%M%S'),uuid.uuid4().hex[:8]))
    path.mkdir(exist_ok=False)
    return path


def check_protocol(loader,gallery,queries):
    if (len(loader.dataset)!=97669 or len(loader.sampler)!=97669 or len(loader)!=3053 or
            loader.sampler.metadata()['train_fingerprint']!=FINGERPRINT or
            len(gallery.dataset)!=33407 or len(queries.dataset)!=3462):
        raise ValueError('UPAR train/validation dataset or QueryBalanced policy differs from baseline')


def run(args):
    config,tc,mc = load_config(args.config)
    if args.smoke_test_steps < 0: raise ValueError('Smoke steps cannot be negative')
    smoke = args.smoke_test_steps > 0
    if smoke and args.smoke_test_steps >= 3053: raise ValueError('Mercury smoke test must stop before epoch 1 completes')
    pretrained = (args.pretrained or ROOT/config['pretrained']).resolve()
    if not pretrained.is_file(): raise FileNotFoundError(pretrained)
    if not args.data_root.is_dir(): raise FileNotFoundError(args.data_root)
    output = new_run_directory(args.output_dir or ROOT/('smoke_runs' if smoke else 'experiments'),smoke)
    tee = Tee(sys.stdout,output/'train.log'); sys.stdout = tee
    status = dict(phase='initializing',test_only=smoke,current_epoch=0,batch=0,global_step=0,
                  completed_full_epochs=0,epoch_11_started=False,normal_exit=False,run_directory=str(output))
    write_json(output/'status.json',status)
    model=optimizer=scheduler=groups=loader=gallery=queries=iterator=monitor=None
    try:
        torch.set_num_threads(1); torch.set_num_interop_threads(1)
        device,gpu = prepare_gpu(args.gpu_device,config['memory']['max_reserved_mib'])
        verify_evidence(args.preflight_dir,args.config,gpu)
        monitor=GPUMonitor(gpu)
        seed_all(tc.seed)
        model = MultiScaleLocalModel.from_local_pretrained(pretrained,mc)
        write_json(output/'pretrained_verification.json',model.initialization_report)
        model.gradient_checkpointing(config['memory']['gradient_checkpointing'])
        model.to(device).train(); assert_model_fp32(model)
        optimizer,groups = optimizer_for(model,tc,config['local_lr'])
        scheduler = build_lr_scheduler(tc,optimizer)
        tokenizer = PromptTokenizer(ROOT/'data/bpe_simple_vocab_16e6.txt.gz')
        loader,gallery,queries = training_loaders(args.data_root,tokenizer,tc)
        check_protocol(loader,gallery,queries)
        config.update(gpu=gpu,pretrained=str(pretrained),data_root=str(args.data_root.resolve()),
                      output_dir=str(output),smoke_test_steps=args.smoke_test_steps,
                      parameter_groups={k:sum(p.numel() for _,p in v) for k,v in groups.items()},
                      sampling=loader.sampler.metadata(),steps_per_epoch=len(loader),
                      attribute_names=list(__import__('upar.attributes',fromlist=['ATTRIBUTE_NAMES']).ATTRIBUTE_NAMES))
        write_json(output/'config.json',config)
        log('Dataset/Sampler ready: '+json.dumps(config['sampling']))
        best = dict(mADM=None,epoch=0,weight=None)
        train_queries=set(loader.dataset.split.queries)
        torch.cuda.reset_peak_memory_stats()
        for epoch in range(1,11):
            model.train(); loader.sampler.set_epoch(epoch)
            loader.generator.manual_seed(tc.seed+epoch-1)
            status.update(phase='training',current_epoch=epoch,batch=0)
            write_json(output/'status.json',status)
            totals={k:0.0 for k in ('loss','sdm_loss','map_loss','attr_bce','attr_loss','map_acc')}; count=0
            started=time.monotonic(); iterator=iter(loader)
            log('Epoch %d/10 start; scheduler_total_epochs=60; lrs=%s' %
                (epoch,json.dumps({g['name']:g['lr'] for g in optimizer.param_groups})))
            for batch_number,batch in enumerate(iterator,1):
                step_start=time.monotonic()
                result=optimizer_update(model,optimizer,batch,config['memory']['micro_batch_size'])
                gradients=gradient_report(model,groups,allow_zero=result['map_tokens']==0 or len(batch['images'])==1)  # Validate every effective batch, including the final partial batch.
                assert_optimizer_fp32(optimizer)
                status['global_step']+=1; count+=len(batch['images'])
                for k in totals: totals[k]+=result[k]*len(batch['images'])
                status.update(batch=batch_number,last_losses=result,gradient_norms=gradients,
                              lrs={g['name']:g['lr'] for g in optimizer.param_groups},
                              peak_allocated_mib=torch.cuda.max_memory_allocated()/1024**2,
                              peak_reserved_mib=torch.cuda.max_memory_reserved()/1024**2,
                              step_seconds=time.monotonic()-step_start,updated_kst=datetime.now(KST).isoformat())
                write_json(output/'status.json',status)
                if smoke or batch_number<=3 or batch_number%tc.log_period==0 or batch_number==len(loader):
                    log('Epoch %d batch %d/%d optimizer_step=%d losses=%s gradients=%s' %
                        (epoch,batch_number,len(loader),status['global_step'],json.dumps(result),json.dumps(gradients)))
                if smoke and status['global_step']>=args.smoke_test_steps:
                    status.update(phase='smoke_complete',stop_reason='smoke_test_steps_reached',
                                  validation_completed=False,formal_checkpoints=[],memory=memory_report(gpu))
                    break
            if smoke: break
            if count!=len(loader.sampler): raise RuntimeError('Incomplete training epoch')
            optimizer.zero_grad(set_to_none=True); iterator=None
            status['phase']='validation';write_json(output/'status.json',status)
            validation=evaluate_local(model,gallery,queries,output/('validation_epoch_%03d'%epoch),train_queries,
                                      micro_batch_size=config['memory']['evaluation_micro_batch_size'])
            score=validation['methods']['Global+NLL']['mADM']; weight=validation['best_weights']['nll']
            if best['mADM'] is None or score>best['mADM']: best=dict(mADM=score,epoch=epoch,weight=weight)
            model.config.fusion_weight=weight
            scheduler.step()  # Identical baseline timing: once, after the complete train + validation epoch.
            path=save_epoch_state_dict(model,epoch,output)
            verification=verify_epoch_state_dict(model,path)
            record=dict(epoch=epoch,global_step=status['global_step'],validation=validation,best=best,
                        mean_losses={k:v/count for k,v in totals.items()},train_seconds=time.monotonic()-started,
                        checkpoint=verification,memory=memory_report(gpu))
            (output/'epoch_records').mkdir(exist_ok=True)
            write_json(output/('epoch_records/epoch_%03d.json'%epoch),record)
            status.update(phase='epoch_complete',completed_full_epochs=epoch,last_validation=validation,best=best)
            write_json(output/'status.json',status)
        if not smoke:
            expected={'epoch_%03d.pth'%e for e in range(1,11)}
            if {p.name for p in output.glob('*.pth')}!=expected: raise RuntimeError('Incorrect final checkpoint set')
            if any((output/n).stat().st_size==0 for n in expected):raise RuntimeError('Empty checkpoint')
            final_verify=verify_epoch_state_dict(model,output/'epoch_010.pth')
            status.update(phase='complete',stop_reason='fixed_epoch_10',checkpoint_files=sorted(expected),
                          epoch_010_strict_reload=final_verify,validation_completed=True,memory=memory_report(gpu))
        log('Training loop exited normally; '+status['stop_reason'])
    except Exception as error:
        status.update(phase='failed',error=str(error),traceback=traceback.format_exc())
        log(status['traceback']);raise
    finally:
        if optimizer is not None: optimizer.zero_grad(set_to_none=True)
        # DataLoader worker lifecycle ends when its iterator is released.
        iterator=loader=gallery=queries=groups=scheduler=optimizer=model=None
        gc.collect()
        if torch.cuda.is_initialized():
            torch.cuda.synchronize();torch.cuda.empty_cache()
            status.update(cuda_allocated_after_cleanup_bytes=torch.cuda.memory_allocated(),
                          cuda_reserved_after_cleanup_bytes=torch.cuda.memory_reserved())
        if monitor is not None:status['nvml_monitor']=monitor.stop()
        status['cuda_cleanup_verified']=status.get('cuda_allocated_after_cleanup_bytes',0)==0 and status.get('cuda_reserved_after_cleanup_bytes',0)==0
        status['normal_exit']=status['phase'] in ('smoke_complete','complete') and status['cuda_cleanup_verified']
        if not status['cuda_cleanup_verified']:
            status.update(phase='failed',error='CUDA allocations remain after cleanup')
        status['completed_kst']=datetime.now(KST).isoformat()
        write_json(output/'status.json',status)
        sys.stdout=tee.console;tee.close()
        print('RUN_DIRECTORY='+str(output),flush=True)
    return output


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root',type=Path,required=True)
    parser.add_argument('--pretrained',type=Path)
    parser.add_argument('--output-dir',type=Path)
    parser.add_argument('--gpu-device',help='Single visible GPU index or UUID; default inherits Pod visibility')
    parser.add_argument('--config',type=Path,default=ROOT/'configs/train_fp32.json')
    parser.add_argument('--smoke-test-steps',type=int,default=0,help='Mercury only: stop normally after N optimizer steps; no epoch weights')
    parser.add_argument('--preflight-dir',type=Path,help='Reuse passed preflight for this exact source/config/GPU; otherwise run it automatically')
    parser.add_argument('--gradient-cache-repeats',type=int,default=3,help='Repeat the same small-batch FP32 equivalence check with the same seed before batch-32 preflight')
    args=parser.parse_args()
    ensure_preflight(args)
    run(args)

if __name__=='__main__': main()
