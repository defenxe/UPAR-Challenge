"""Pure CPU tests for the numerical acceptance policy in verify_gradient_cache."""
import unittest

from tests.verify_gradient_cache import gradient_acceptance, update_acceptance


class GradientAcceptanceTests(unittest.TestCase):
    def _gradient(self, relative=5.499150260092126e-4,
                  maximum=0.18421077728271484, finite=True, missing=0):
        return dict(
            relative_l2=relative,
            max_absolute_error=maximum,
            nan_inf=dict(reference=not finite, cache=not finite),
            missing_gradient_count=missing,
        )

    def test_reported_rtx_2080_ti_observation_is_inside_composite_bounds(self):
        result = gradient_acceptance(self._gradient())
        self.assertTrue(result['passed'])
        self.assertTrue(result['legacy_strict_limit_exceeded'])
        self.assertTrue(result['relative_l2_passed'])
        self.assertTrue(result['max_absolute_error_passed'])

    def test_relative_error_above_platform_bound_fails(self):
        result = gradient_acceptance(self._gradient(relative=1.0001e-3))
        self.assertFalse(result['passed'])
        self.assertFalse(result['relative_l2_passed'])

    def test_absolute_error_above_bound_fails(self):
        result = gradient_acceptance(self._gradient(maximum=0.250001))
        self.assertFalse(result['passed'])
        self.assertFalse(result['max_absolute_error_passed'])

    def test_nonfinite_or_missing_gradient_fails(self):
        self.assertFalse(gradient_acceptance(self._gradient(finite=False))['passed'])
        self.assertFalse(gradient_acceptance(self._gradient(missing=1))['passed'])


class AdamUpdateAcceptanceTests(unittest.TestCase):
    def _update(self, relative=2.431e-4, maximum=4.089e-7, finite=True):
        return dict(relative_l2=relative,
                    max_absolute_update_difference=maximum,
                    nan_inf=not finite)

    def test_measured_mercury_adam_update_is_inside_bounds(self):
        self.assertTrue(update_acceptance(self._update())['passed'])

    def test_relative_update_error_above_bound_fails(self):
        self.assertFalse(update_acceptance(self._update(relative=5.001e-4))['passed'])

    def test_absolute_update_error_above_bound_fails(self):
        self.assertFalse(update_acceptance(self._update(maximum=2.001e-6))['passed'])

    def test_nonfinite_update_fails(self):
        self.assertFalse(update_acceptance(self._update(finite=False))['passed'])


if __name__ == '__main__':
    unittest.main()
