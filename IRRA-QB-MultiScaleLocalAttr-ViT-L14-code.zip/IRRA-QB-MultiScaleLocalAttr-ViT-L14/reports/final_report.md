# ViT-L/14 MultiScale Local Attribute 구현 및 Mercury 검증 보고서

완료: 새 독립 프로젝트를 구성하고, TITAN Xp에서 실제 Epoch 1의 Batch 32 Optimizer Step 5개를 수행한 뒤 정상 종료했습니다. 실제 완료 Epoch는 0입니다. Mercury에서 10 Epoch 학습을 수행하지 않았습니다.

## 구현

- 프로젝트: `/root/workplace/UPAR-Challenge-2027-main/IRRA-QB-MultiScaleLocalAttr-ViT-L14`.
- Visual: 24 Layers / Width 1024 / Heads 16 / Patch 14. Text: 12 Layers / Width 768 / Heads 12 / Context 77. Joint Embedding 768.
- 입력 378×126, Grid 27×9. Position Spatial Grid 16×16→27×9 bilinear FP32 보간, CLS Position 그대로 유지.
- Base Layer 4/8/12의 1/3, 2/3, 마지막 깊이에 대응하는 Large Layer 8/16/24를 사용합니다. 중간 Patch `[B,243,1024]`를 LayerNorm+Linear로 768에 맞춥니다. 마지막 Layer는 기존 CLIP ln_post 및 1024→768 Projection을 사용합니다.
- Local Head의 40 Attribute Queries, 8 Heads 및 Scale 초기값 0.2/0.2/0.6을 유지합니다. MAP 4 Layers / Width 768 / Heads 12.
- QueryBalanced, Attribute 순서, Prompt/BPE, Masking, SDM/MAP 수식, Local 0.5×BCE, Global/Local Fusion, Metric/Fusion sweep 유지. Loss/Metric/Sampler의 동일성은 `baseline_preservation.json`에 기록했습니다.
- Trainable Parameters: 500,915,499. Groups: `{"image": 303952896, "text": 123650304, "map": 69305344, "local": 2428456, "multiscale": 1578499}`. Frozen Parameters 0.
- Original Adam 및 60 Epoch Scheduler 유지. Backbone/Text/MAP nominal LR 1e-5, Local/MultiScale 1e-4. Beta .9/.999, epsilon .001, decay 4e-5. Linear warmup 5 Epoch, factor .1, 이후 cosine. Scheduler Step은 완료 Epoch의 Validation 뒤 한 번. Effective Batch 32, Seed 1, Validation 매 Epoch, Gradient Clipping 없음.
- `scheduler_total_epochs=60`, `training_stop_epoch=10`. 첫 10 Epoch LR 일치를 CPU에서 검증했습니다 (`lr_first10.json`).

## Pretrained

- 실제 파일: `/root/workplace/UPAR-Challenge-2027-main/IRRA-QB-MultiScaleLocalAttr-ViT-L14/weights/ViT-L-14.pt`.
- 크기: 932,768,134 bytes (889.557 MiB).
- SHA256: `b8cca3fd41ae0c99ba7e8951adf17d267cdb84cd88be6f7c2e0eca1737a03836`.
- [공식 OpenAI CLIP 등록 URL/체크섬](https://github.com/openai/CLIP/blob/main/clip/clip.py)에서 다운로드했습니다. `pretrained_download.log`에 다운로드와 checksum 일치를 기록했습니다.
- TorchScript Archive 확인. Backbone 445 Key 모두 strict 로딩 후 Tensor 값 비교 일치. Missing/Unexpected/Shape mismatch 없음. 공식 Visual/Text Transformer Block 수 및 Projection/Embedding Shape 확인.
- Raw Shapes: Conv `[1024,3,14,14]`, Visual Position `[257,1024]`, Visual Projection `[1024,768]`, Token Embedding `[49408,768]`, Text Position `[77,768]`, Text Projection `[768,768]`.
- SHA/파일/Shape 실패 시 중단하며 무작위 Backbone 대체 없음. 기본 Pretrained 경로는 프로젝트 내부입니다. Git ignore 설정 완료; ZIP에는 실제 Weight를 포함해야 합니다.

## Gradient Cache 및 수치 검증

- Micro-Batch 1 × Replay 32, Effective Batch 32. 전체 32×32 SDM을 한 번 계산한 뒤 양 Encoder에 Feature Gradient를 전달합니다. MAP은 전체 선택 토큰 수, BCE는 전체 샘플 수를 분모로 사용합니다. Optimizer Step은 Effective Batch당 한 번입니다.
- Visual/Text/MAP Transformer Block의 FP32 Activation Recomputation. AMP/FP16/BF16/TF32 사용 없음. CUDA Allocator Budget 9600 MiB.
- 실제 ViT-L/14 Batch 2 Full-Batch와 Micro 1 Cache에서 동일 Weight/Mask/RNG, 실제 Epoch 1 Warmup LR로 비교했습니다. Loss rtol/atol 2e-5, Branch Gradient 상대 L2 ≤ 2e-4, Adam rtol 2e-5 / atol 2e-6 기준 통과.
- 초기 개별 원소 절대 오차 기준은 FP32 Batch 분해에 따른 reduction 차이를 과도하게 제한했습니다. Branch별 전체 Gradient 상대 L2를 통과 기준으로 명시했고, 개별 오차는 진단 로그에 보존했습니다. 초기 nominal-LR Adam 테스트도 진단 로그에 남겼으며, 최종 비교는 실제 Epoch 1 Warmup 설정으로 수행했습니다.
- Adam Update 최대 절대 차이: `4.0885061025619507e-07`.

| Branch | Gradient 상대 L2 | Gradient 최대 절대 차이 |
|---|---:|---:|
| image | 6.8907568e-05 | 0.011169434 |
| text | 2.8414301e-06 | 0.00012207031 |
| map | 2.5274197e-06 | 4.5001507e-06 |
| local | 1.5495341e-06 | 9.6857548e-08 |
| multiscale | 1.1781469e-06 | 3.5390258e-08 |

- CPU: Core 5개 + Lifecycle 1개 + Validation Math 1개 테스트 통과. Batch 32, 불완전 Batch 5, 선택 MAP Token 0, Recomputation, LR, Exclusive Checkpoint 저장 및 Epoch 10 종료 순서 포함. Lifecycle의 10 Epoch는 작은 CPU Fixture이며 실제 Dataset 학습이 아닙니다.

## GPU 검증

- GPU: NVIDIA TITAN Xp / UUID `GPU-9a73d385-17e4-100c-dbf9-ebcded50c3d4` / 12196 MiB / CUDA Capability 6.1.
- 현재 TITAN Xp만 사용했습니다. RTX 2080 Ti 실기와 Kubernetes Pod에서는 테스트하지 않았습니다. 아래 메모리 값은 TITAN Xp 측정값이며 RTX 2080 Ti 성공을 확정하지 않습니다.

| 테스트 | Peak Allocated MiB | Peak Reserved MiB | NVML 샘플 최대 전체 사용 MiB |
|---|---:|---:|---:|
| 수치 동등성 | 8057.743 | 8388 | 별도 모니터 없음 |
| Batch 32 Preflight | 8052.357 | 8388 | 9127 |
| Epoch 1 Smoke 5 Step | 8126.281 | 8542 | 9281 |

- NVML 요청 Sampling Interval 200ms, Smoke 151 Samples. GPU 전체 9281 MiB는 약 9.064 GiB로 11 GiB보다 약 1.936 GiB 낮습니다. 실제 RTX 2080 Ti의 Driver/Workspace 및 가용 VRAM은 이전 후 Preflight로 확인해야 합니다.
- 실제 Dataset/Sampler 초기화: Train 97,669 / 7,204 Groups / 3,053 Batches; Val 33,407 Gallery / 3,462 Queries. Data Root, CSV/이미지 경로, BPE, Config, Pretrained 검증 통과.
- Batch 32 Forward / 전체 SDM+MAP+Local BCE / Backward / Adam Step / 모든 Branch finite nonzero Gradient / Optimizer State finite FP32 확인. CUDA OOM 없음.
- 임시 순수 Model Weight 2,003,869,657 bytes / 532 Tensor를 저장한 뒤 strict 재로딩 및 모든 값 일치를 확인하고 삭제했습니다. 정식 Epoch Weight가 아닙니다.
- 실제 Validation Gallery 2개 / Query 2개 Forward: Image Token `[2,244,768]`, Text `[2,768]`, Attribute `[2,40]`, Layer 8/16 Patch `[2,243,1024]`. 모두 finite. 전체 Validation Metric 실행이나 Epoch Validation 완료로 취급하지 않습니다.

## Epoch 1 실제 학습 및 종료

- Run: `/root/workplace/UPAR-Challenge-2027-main/IRRA-QB-MultiScaleLocalAttr-ViT-L14/smoke_runs/smoke_20261013_104933_KST_2782675c`.
- `--smoke-test-steps 5`로 Epoch 1 Batch 32 × 5 = 160 Sampling Draws, Optimizer Step 5개를 연속 완료했습니다. SDM은 매번 32×32였습니다.

| Step | SDM | MAP | 0.5×BCE | Total |
|---:|---:|---:|---:|---:|
| 1 | 27.635143 | 10.771083 | 0.406376 | 38.812603 |
| 2 | 27.907185 | 10.815516 | 0.403845 | 39.126546 |
| 3 | 26.960251 | 10.718385 | 0.385362 | 38.063998 |
| 4 | 26.850321 | 10.726543 | 0.373852 | 37.950716 |
| 5 | 26.869606 | 10.694650 | 0.358301 | 37.922557 |

- 모든 Step의 Loss/Gradient와 Adam State가 finite FP32. NaN/Inf 및 OOM 없음. 마지막 Step Gradient Norm은 `{"image": 158.13194274902344, "text": 120.74839782714844, "map": 20.088335037231445, "local": 2.021475315093994, "multiscale": 0.5235739350318909}`.
- 최종 `phase=smoke_complete`, `normal_exit=true`, `current_epoch=1`, `batch=5`, `global_step=5`, `completed_full_epochs=0`. Stop Reason `smoke_test_steps_reached`.
- 최종 학습 Process Exit Code 0. SIGKILL 없이 루프가 반환해 종료했습니다. 모든 최종 검증 Process도 Exit Code 0이며 장기 학습 Process를 남기지 않았습니다.
- CUDA Allocated/Reserved Cleanup: 0 / 0 bytes. Process 종료 후 nvidia-smi 전체 사용량 **0 MiB**, 남은 테스트 Python/Monitor Process 없음.
- Epoch 1 전체, Epoch 2, 실제 10 Epoch 학습을 실행하지 않았습니다. Smoke Run의 `.pth` 0개. 임시 Preflight Weight는 삭제했습니다.
- Step 수 구분: 실제 Epoch 1 학습 5 / GPU Preflight 1 / 최종 수치 비교 2. 이전 실패 진단 비교에서 3회 추가 Update가 있었으며 모두 폐기한 검증 모델입니다. 총 테스트 GPU Update 11회가 정식 학습이나 Epoch 완료를 의미하지 않습니다.

## Kubernetes 실행 준비

프로젝트를 압축 해제한 디렉터리에서 GPU 1개와 Dataset/Output Volume을 할당한 뒤 실행합니다. 아래 경로는 Pod의 실제 Mount Path에 맞춰 인자로 지정하면 됩니다. 코드 수정은 필요하지 않습니다.

```bash
cd /workspace/IRRA-QB-MultiScaleLocalAttr-ViT-L14
PYTHON_BIN=python bash scripts/run_kubernetes.sh \
  --data-root /data/upar \
  --pretrained weights/ViT-L-14.pt \
  --output-dir /outputs/IRRA-QB-MultiScaleLocalAttr-ViT-L14 \
  --gpu-device 0 \
  --config configs/train_fp32.json
```

- `--smoke-test-steps`는 위 정식 명령에 없으며 기본 0, 비활성입니다. Mercury GPU UUID 하드코딩 없음. Pod의 CUDA_VISIBLE_DEVICES를 상속하려면 --gpu-device를 생략하십시오.
- 새 GPU에서 Gradient Cache 및 Batch 32 Preflight를 자동 실행하고, 통과 후 공식 Pretrained에서 정식 모델을 새로 초기화합니다. 해당 GPU에 다른 Process가 점유 중이면 변경하지 않고 실패합니다.
- 정식 Config: `configs/train_fp32.json`. Baseline 비교에 필요한 `reports/baseline_config.json` 필수.
- Data Root: `annotations/task2/train/{gt,ids,queries}.csv`, `annotations/task2/val/{gt,ids,queries}.csv`, CSV의 상대 경로에 해당하는 모든 이미지. Dataset은 ZIP에 포함하지 않습니다.
- Linux, GPU 1개, NVIDIA Driver/CUDA Runtime, nvidia-smi, Python 3.7~3.10, torch 1.12.1 + torchvision .13.1, numpy/Pillow. 실제 Mercury 버전은 `environment.json`; CUDA 11.3 설치 파일은 `requirements.cuda113.txt`.
- Checkpoint: Output 아래 고유 `train_e10_<KST>_<id>/epoch_001.pth`~`epoch_010.pth`. 각 Epoch Training+Validation 완료 후 모델 state_dict만 저장. 기존 파일 Exclusive Create 보호. Optimizer/Scheduler 및 best/last/latest/recovery 저장 없음.
- Epoch 10: 마지막 Batch → Validation → epoch_010 저장 → 10개 파일 존재 확인 → epoch_010 strict 재로딩 → Metric/종료 상태 → CUDA 정리 → 정상 반환. Epoch 11 루프 없음.
- ZIP 필수: weights/ViT-L-14.pt, data/BPE, upar/model/solver/datasets/utils/configs/scripts/tests, train_full_upar.py, validate_upar.py, README, LICENSE, requirements*.txt, reports/baseline_config.json. 검증 Report/JSON/Log는 선택적으로 포함하십시오. experiments/smoke_runs/__pycache__는 배포에 필요하지 않습니다.
- Git Ignore된 Weight도 실제 ZIP에 반드시 포함하십시오. ZIP 제작/업로드/Kubernetes 접근은 이번 작업에서 수행하지 않았습니다.

## 보호 및 검증 근거

- FullTrain 66 / QueryBalanced ViT-L14 38 / QueryBalanced 76 Source 파일 Hash 일치. 코드 변경 없음. Original Checkpoint, 다른 학습, Docker 및 GPU Reset에 쓰기/종료 명령을 수행하지 않았습니다. IRRA-QB-LODO 경로는 현재 Container에 없었습니다.
- 핵심 근거: pretrained_verification.json, gradient_cache_gpu.json, gpu_preflight.json, final_summary.json, unit_tests.json, lifecycle_tests.json, validation_math.log, protected_verification.json 및 Smoke Run status.json/train.log.
