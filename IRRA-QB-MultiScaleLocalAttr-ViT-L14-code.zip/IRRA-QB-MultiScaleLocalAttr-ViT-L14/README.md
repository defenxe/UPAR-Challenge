# IRRA-QB-MultiScaleLocalAttr-ViT-L14

독립적인 공식 OpenAI CLIP ViT-L/14 기반 QueryBalanced + MultiScale Local Attribute 학습 프로젝트입니다.
원본 FullTrain의 Attribute 순서, Prompt/BPE, Sampling, Loss, Metric, Adam과 60 Epoch LR 스케줄을 유지합니다.
정식 실행은 **Epoch 1~10만** 학습합니다. Mercury 검증 실행은 **Epoch 1의 5개 Optimizer Step만** 수행하며, 정식 Epoch Weight를 만들지 않습니다.

## 모델 및 변경 범위

- Visual: 24 Layers, Width 1024, Heads 16, Patch/Stride 14.
- Text: 12 Layers, Width 768, Heads 12, Context 77, Vocabulary 49408.
- Joint Embedding: 768. MAP Cross-Modal Transformer 4 Layers, Width 768, Heads 12.
- 입력: Height 378 × Width 126, 3:1, Patch Grid 27×9. CLS 포함 Image Token `[B,244,768]`.
- Pretrained Position: 16×16 Spatial Grid를 FP32 bilinear (`align_corners=False`)로 27×9에 보간. CLS Position은 그대로 보존.
- 원본의 4/8/12는 깊이의 1/3, 2/3, 마지막 Layer이므로 Large에서는 **8/16/24** 사용.
- 중간 Layer 8/16: `[B,243,1024]` → 기존과 같은 LayerNorm + Linear, 출력 768.
- 마지막 Layer 24: 기존 CLIP의 ln_post + 1024→768 Projection을 그대로 사용.
- Local Branch: 40 Attribute Queries, 기존 8 Attention Heads, CLS 제외, Patch 수 243. 초기 Scale Weights `[0.2,0.2,0.6]` 유지.
- Global Retrieval, SDM, MAP, `0.5 × BCEWithLogits(mean)`, Fusion 및 Validation Metric/Best Weight 선택 방식 유지. 추가 Loss와 Frozen Parameter 없음.
- Training은 원본의 Horizontal Flip을 유지하고 Validation은 Flip을 사용하지 않습니다. Resize, RGB, CLIP Normalize는 동일합니다.

## 공식 Pretrained

`weights/ViT-L-14.pt`가 프로젝트 내부에 실제 포함되어 있습니다. 외부 프로젝트나 캐시를 참조하지 않습니다.

공식 URL 및 SHA256 기준은 [OpenAI CLIP 소스](https://github.com/openai/CLIP/blob/main/clip/clip.py)의 ViT-L/14 항목입니다.

- Bytes: 932,768,134 (889.557 MiB)
- SHA256: `b8cca3fd41ae0c99ba7e8951adf17d267cdb84cd88be6f7c2e0eca1737a03836`
- TorchScript Archive의 Backbone Key 445개를 전부 strict 로딩하고 Tensor 값을 비교합니다.
- Position 보간 이외의 Backbone Tensor는 공식 파일의 FP32 변환 결과와 동일합니다.
- 누락, Shape 불일치, SHA256 불일치 또는 파일 부재 시 실행 실패. 무작위 Backbone 초기화 대체 없음.
- `.gitignore`는 Weight의 Git 자동 포함을 막습니다. **ZIP에는 반드시 Weight를 포함해야 합니다.**

## FP32 및 Gradient Cache

AMP/FP16/BF16/TF32를 사용하지 않습니다. 모델, Gradient, Adam Moment는 FP32입니다.
기본 Micro-Batch **1**, Effective Batch **32**, Replay Micro-Batch **32회**입니다.

1. No-Grad Micro-Batch Pass로 Image/Text Global Feature를 모읍니다.
2. 전체 Effective Batch로 양방향 **32×32 SDM Matrix**를 계산하고 Feature Gradient를 구합니다.
3. RNG를 재현하며 Encoder를 다시 실행하고 SDM Feature Gradient를 Image/Text 양쪽으로 전달합니다.
4. 같은 Replay에서 MultiScale/Local BCE와 MAP을 계산합니다.
5. MAP은 `Micro-Batch 선택 토큰 수 / 전체 선택 토큰 수`, BCE는 `Micro-Batch 샘플 수 / 전체 샘플 수`로 Scaling합니다.
6. Effective Batch마다 Adam을 **한 번** 실행합니다. 마지막 Batch 5개도 5×5 SDM과 정확한 분모를 사용합니다.

Visual/Text/MAP Transformer의 모든 Block에서 FP32 Activation Recomputation을 수행합니다.
Dropout=0과 BatchNorm 부재를 확인합니다. Masking은 Dataset에서 한 번 결정한 Tensor를 두 Pass에 재사용합니다.
기본 CUDA Allocator 상한은 **9600 MiB**입니다. 실제 NVML 전체 GPU 메모리도 200ms 간격으로 기록합니다.
TITAN Xp에서 검증한 결과는 RTX 2080 Ti 실기 검증을 대신하지 않습니다.

## 실행 환경

Linux, CUDA GPU 1개, `nvidia-smi`, Dataset 마운트, 쓰기 가능한 Output Volume이 필요합니다.
현재 환경 정보는 `reports/environment.json`에 기록합니다.

재현 환경은 Python 3.7~3.10 + PyTorch 1.12.1 / torchvision 0.13.1입니다.
CUDA 11.3 Wheel 설치 예시는 다음과 같습니다. Host NVIDIA Driver가 해당 CUDA Runtime을 지원해야 합니다.

```bash
python -m pip install -r requirements.cuda113.txt
```

[PyTorch 공식 이전 버전 설치 문서](https://pytorch.org/get-started/previous-versions/)의 CUDA 11.3 설정을 사용합니다.
이미 CUDA-enabled PyTorch 환경이 있다면 일치하는 torch/torchvision 조합을 유지하십시오.
`requirements.txt`는 공통 의존성을 명시합니다. 다른 PyTorch 버전에서의 수치/메모리는 Preflight로 다시 확인합니다.

Dataset은 프로젝트에 포함되지 않습니다. Data Root 구조:

```text
/data/upar/
  annotations/task2/train/{gt,ids,queries}.csv
  annotations/task2/val/{gt,ids,queries}.csv
  <CSV에 기재된 상대 경로의 모든 이미지>
```

원본 프로토콜의 Train 97,669 Images / 7,204 Query Groups / 3,053 Effective Batches,
Validation 33,407 Gallery / 3,462 Queries와 Fingerprint를 검증합니다.
Data Root 하위의 실제 CSV 경로를 유지하십시오.

## Kubernetes 정식 실행

Pod에 GPU 한 개와 Dataset/Output Volume을 할당한 뒤, 압축 해제한 프로젝트 디렉터리에서 실행합니다.
Mercury UUID가 실행 스크립트에 들어 있지 않습니다. `--gpu-device 0`은 해당 Pod에서 보이는 GPU 한 개를 선택합니다.
Pod의 기존 `CUDA_VISIBLE_DEVICES`를 그대로 쓰려면 `--gpu-device`를 생략할 수 있습니다.

```bash
cd /workspace/IRRA-QB-MultiScaleLocalAttr-ViT-L14
PYTHON_BIN=python bash scripts/run_kubernetes.sh \
  --data-root /data/upar \
  --pretrained weights/ViT-L-14.pt \
  --output-dir /outputs/IRRA-QB-MultiScaleLocalAttr-ViT-L14 \
  --gpu-device 0 \
  --config configs/train_fp32.json
```

**Step 제한은 기본 0(비활성)**입니다. 정식 명령에는 `--smoke-test-steps`를 넣지 않습니다.
이 명령은 먼저 해당 GPU에서 Gradient Cache 수치 비교와 GPU Preflight를 실행하고,
통과한 경우 새 모델/Adam/Scheduler를 공식 Weight에서 다시 초기화해 정식 학습을 시작합니다.
다른 GPU 프로세스가 이미 GPU를 점유하면 그 프로세스를 변경하지 않고 실패합니다.
Kubernetes Pod에서는 직접 실행해 보지 않았습니다.

실행 인자: Data Root, Pretrained, Output Directory, GPU Device, Config.
프로젝트 파일 기본 경로는 프로젝트 루트를 기준으로 계산합니다.
외부 Data Root/Output은 실행 인자로 지정합니다.

## Scheduler 및 Checkpoint

`configs/train_fp32.json`:

- `scheduler_total_epochs=60`, `train.num_epoch=60`, `training_stop_epoch=10`.
- Adam, LR Backbone/Text/MAP `1e-5`, Local/MultiScale `1e-4`.
- Beta `(0.9,0.999)`, Epsilon `0.001`, Weight Decay `4e-5`.
- Warmup 5 Epoch, Factor 0.1, Linear. 이후 원본 Cosine, Target LR 0.
- Scheduler는 전체 Training + Validation 완료 후 Epoch마다 한 번 Step.
- Seed 1, QueryBalanced `count^-0.5`, Replacement, `seed + epoch - 1`.
- Validation 매 Epoch, Gradient Clipping 없음.

`reports/baseline_config.json`의 원본 설정과 비교하여 예상하지 않은 변경을 거부합니다.
`reports/lr_first10.json`에 Epoch별 LR을 기록합니다.

Output 아래 `train_e10_<KST시간>_<고유ID>/`를 새로 생성합니다.
각 Epoch의 **전체 Training 및 Validation 완료 후** 순수 `model.state_dict()`를 저장합니다.

```text
train_e10_.../
  epoch_001.pth ... epoch_010.pth
  config.json
  status.json
  train.log
  epoch_records/epoch_001.json ... epoch_010.json
  validation_epoch_001/ ... validation_epoch_010/
```

Optimizer/Scheduler State, `best.pth`, `last.pth`, `latest.pth`, `recovery.pth`는 저장하지 않습니다.
파일은 Exclusive Create로 생성해 기존 Weight를 덮어쓰지 않습니다.
Epoch 10 Training → Validation → `epoch_010.pth` 저장 → 10개 파일 확인 → Epoch 10 strict 재로딩 → 종료 상태 기록 → CUDA 정리 → 정상 종료.
Epoch 11을 실행하는 루프가 없습니다. Best Score는 Metric 기록에만 사용합니다.
10개의 순수 Model Weight만 약 18.7 GiB이며, Validation Score/Feature Artifact를 포함한 Output 저장 공간도 확보해야 합니다.

## Mercury Smoke Test 및 검증

```bash
python tests/test_core.py
python tests/test_lifecycle.py
python tests/verify_gradient_cache.py --data-root /path/to/upar
python tests/gpu_preflight.py --data-root /path/to/upar
python train_full_upar.py --data-root /path/to/upar \
  --output-dir smoke_runs --preflight-dir reports --smoke-test-steps 5
```

Preflight를 재사용할 때는 현재 소스/Config Hash와 GPU UUID가 모두 일치해야 합니다.
`--preflight-dir`를 생략하면 새 Preflight를 자동 실행합니다.
GPU 수치 비교는 실제 모델 Batch 2와 Micro-Batch 1, 동일 초기 Weight/Mask/RNG에서 수행합니다.
Loss FP32 허용 오차, 각 Branch의 전체 Gradient 상대 L2 및 Adam Update를 검사합니다.
개별 원소 오차는 로그로 기록하고, Gradient는 Branch별 상대 L2 ≤ 2e-4를 통과 기준으로 사용합니다.
CPU 테스트는 Batch 32, 불완전 Batch 5, MAP 선택 토큰 0, Recomputation, LR, Checkpoint 정책을 검사합니다.
`test_lifecycle.py`의 Epoch 1~10은 작은 **CPU Fixture**로 종료 순서만 테스트하며 실제 Dataset의 10 Epoch 학습이 아닙니다.

Mercury 실학습은 `smoke_.../`에서 Epoch 1의 지정된 Step까지만 진행합니다.
정식 Epoch Checkpoint/Validation 완료로 취급하지 않습니다. Preflight의 임시 Weight는 strict 재로딩 후 삭제합니다.
최종 GPU 메모리 및 정상 종료 증거는 `reports/final_report.md`를 확인하십시오.

## 추론

```python
from upar.local_inference import LocalRetrievalEngine
engine = LocalRetrievalEngine('/outputs/run/epoch_010.pth', device='cuda:0', batch_size=2,
                              fusion_weight=0.4, attribute_score='nll')
result = engine.rank_gallery(sample)
```

공식 `sample`의 Attribute 순서 및 Gallery 순서를 유지합니다.
Validation에서 선택된 Fusion Weight는 해당 Epoch의 `epoch_records/epoch_010.json`에 기록됩니다.
순수 Model State에는 Fusion 선택 메타데이터를 넣지 않으므로, 추론 시 해당 Weight를 인자로 전달합니다.
Global-only는 `fusion_weight=0.0`입니다.

## ZIP에 포함할 파일

`weights/ViT-L-14.pt`, `data/bpe_simple_vocab_16e6.txt.gz`, `upar/`, `model/`, `solver/`,
`datasets/`, `utils/`, `configs/`, `scripts/`, `tests/`, `train_full_upar.py`, `validate_upar.py`, `README.md`,
`LICENSE`, `requirements*.txt`, 그리고 설정 비교에 필요한 **`reports/baseline_config.json`**.
검증 근거를 위해 `reports/`의 JSON/로그/최종 보고서도 함께 포함할 수 있습니다.
`experiments/`, `smoke_runs/`, `__pycache__/`는 배포에 필요하지 않습니다.
`.gitignore` 때문에 Git Archive만으로 패키징하면 공식 Weight가 빠질 수 있으므로 프로젝트 폴더의 실제 파일을 포함하십시오.
이번 작업에서는 ZIP 제작이나 Kubernetes 업로드를 수행하지 않습니다.
