"""Only the local branch changes: weighted patch features from blocks 8/16/24."""
from dataclasses import dataclass
import torch
from torch import nn
import torch.nn.functional as F
from model.clip_model import CLIP
from model.objectives import compute_attribute_sdm, compute_map
from .local_model import GlobalLocalModel, LocalModelConfig
from .masking import IGNORE_INDEX

ARCHITECTURE = 'qb-multiscale-local-vit-l14-8-16-24-weighted-v1'


@dataclass
class MultiScaleModelConfig(LocalModelConfig):
    multiscale_blocks: tuple = (8, 16, 24)
    initial_scale_weights: tuple = (0.2, 0.2, 0.6)


class WeightedPatchFusion(nn.Module):
    def __init__(self, weights):
        super().__init__()
        self.norms = nn.ModuleDict({str(b): nn.LayerNorm(1024) for b in (8, 16)})
        self.projections = nn.ModuleDict({str(b): nn.Linear(1024, 768) for b in (8, 16)})
        self.fusion_logits = nn.Parameter(torch.tensor(weights).float().log())

    def aligned(self, intermediate, final):
        if set(intermediate) != {8, 16} or final.shape[1:] != (244, 768):
            raise ValueError('Require blocks 8/16 and final projected CLIP tokens')
        features = []
        for block in (8, 16):
            raw = intermediate[block]
            if raw.shape != (len(final), 243, 1024):
                raise ValueError('Intermediate features must exclude CLS: [B,192,768]')
            features.append(self.projections[str(block)](self.norms[str(block)](raw)))
        # Block 24 already passed through CLIP ln_post and 1024->768 projection.
        features.append(final[:, 1:])
        return features

    def forward(self, intermediate, final):
        features = self.aligned(intermediate, final)
        weights = self.fusion_logits.softmax(0)
        # No [B,3,192,512] stack or extra encoder passes.
        return sum(weights[k] * feature for k, feature in enumerate(features))


class MultiScaleLocalModel(GlobalLocalModel):
    def __init__(self, clip_model, clip_config, config=None, with_map=True):
        config = config or MultiScaleModelConfig()
        if tuple(config.multiscale_blocks) != (8, 16, 24):
            raise ValueError('This experiment fixes blocks 8/16/24 (indices 7/15/23)')
        weights = torch.tensor(config.initial_scale_weights)
        if not torch.isfinite(weights).all() or not (weights > 0).all() or abs(float(weights.sum()) - 1) > 1e-6:
            raise ValueError('Initial fusion weights must be positive and sum to one')
        super().__init__(clip_model, clip_config, config, with_map)
        # Preserve fresh QB MAP and parent RNG initialization exactly.
        with torch.random.fork_rng(devices=[]):
            self.multiscale = WeightedPatchFusion(config.initial_scale_weights)

    def image_tokens_and_scales(self, images):
        return self.base_model.visual(images.type(self.base_model.dtype), return_intermediate=True)

    def local_from_tokens(self, image_tokens, intermediate):
        return self.local_branch(self.multiscale(intermediate, image_tokens))[0]

    def encode_image_and_attributes(self, images):
        tokens, intermediate = self.image_tokens_and_scales(images)
        return tokens[:, 0].float(), self.local_from_tokens(tokens, intermediate)

    def gradient_checkpointing(self, enabled=True):
        for transformer in (self.base_model.visual.transformer,
                            self.base_model.transformer,
                            self.cross_modal_transformer):
            transformer.gradient_checkpointing = bool(enabled)

    def global_features(self, batch):
        tokens, intermediate = self.image_tokens_and_scales(batch['images'])
        text = self.encode_text(batch['caption_ids'])
        return tokens[:, 0].float(), text, (tokens, intermediate)

    def auxiliary_result(self, batch, features):
        tokens, intermediate = features
        masked = self.base_model.encode_text(batch['map_ids'])
        fused = self.cross_former(masked, tokens, tokens)
        selected = batch['map_labels'].ne(IGNORE_INDEX)
        scores = self.mlm_head(fused[selected]).float()
        labels = batch['map_labels'][selected]
        logits = self.local_from_tokens(tokens, intermediate)
        attributes = batch['attributes']
        if attributes.shape != logits.shape or not ((attributes == 0) | (attributes == 1)).all():
            raise ValueError('Require binary [B,40] attribute labels in official order')
        bce = F.binary_cross_entropy_with_logits(logits.float(), attributes.float())
        return dict(map_loss=compute_map(scores, labels) * self.config.map_loss_weight,
                    map_tokens=selected.sum(), map_correct=scores.argmax(-1).eq(labels).sum(),
                    attr_bce=bce, attr_loss=bce * self.config.attr_loss_weight)

    def forward(self, batch):
        if not self.training or not self.with_map:
            raise RuntimeError('Training requires train mode and MAP modules')
        image_tokens, intermediate = self.image_tokens_and_scales(batch['images'])
        token_ids = batch['caption_ids']
        text_tokens = self.base_model.encode_text(token_ids)
        eos = token_ids.eq(49407).long().argmax(1)
        text_global = text_tokens[torch.arange(len(token_ids), device=token_ids.device), eos].float()
        sdm = compute_attribute_sdm(image_tokens[:, 0].float(), text_global,
                                    batch['attributes'], self.logit_scale)
        masked = self.base_model.encode_text(batch['map_ids'])
        fused = self.cross_former(masked, image_tokens, image_tokens)
        selected = batch['map_labels'].ne(IGNORE_INDEX)
        scores = self.mlm_head(fused[selected]).float()
        labels = batch['map_labels'][selected]
        map_loss = compute_map(scores, labels) * self.config.map_loss_weight
        accuracy = scores.argmax(-1).eq(labels).float().mean() if labels.numel() else scores.sum() * 0
        logits = self.local_from_tokens(image_tokens, intermediate)
        attributes = batch['attributes']
        if attributes.shape != logits.shape or not ((attributes == 0) | (attributes == 1)).all():
            raise ValueError('Attribute BCE labels must be binary [B,40] in official order')
        bce = F.binary_cross_entropy_with_logits(logits.float(), attributes.float())
        return {'sdm_loss': sdm, 'map_loss': map_loss, 'attr_bce': bce,
                'attr_loss': self.config.attr_loss_weight * bce, 'attribute_logits': logits,
                'map_acc': accuracy, 'map_tokens': selected.sum(),
                'temperature': self.logit_scale.reciprocal()}


