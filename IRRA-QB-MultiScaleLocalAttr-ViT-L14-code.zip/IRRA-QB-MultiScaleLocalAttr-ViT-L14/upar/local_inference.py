"""Offline local/global retrieval; validation and application inference only."""
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from .attributes import check_attribute_names
from .inference import SampleGallery
from .multiscale_model import MultiScaleLocalModel, MultiScaleModelConfig
from .pretrained import CLIP_CONFIG
from model.clip_model import CLIP
from .checkpoint import load_checkpoint
from .precision import configure_fp32
from .local_scoring import attribute_scores, fuse
from .prompts import encode_query
from .tokenizer import PromptTokenizer


class LocalRetrievalEngine:
    def __init__(self, checkpoint_path, bpe_path=None, device='auto', batch_size=2,
                 fusion_weight=None, attribute_score=None):
        self.device = torch.device('cuda' if device=='auto' and torch.cuda.is_available() else
                                   'cpu' if device=='auto' else device)
        configure_fp32()
        self.model = MultiScaleLocalModel(CLIP(**CLIP_CONFIG).float(),dict(CLIP_CONFIG),MultiScaleModelConfig(),with_map=True)
        self.model.load_state_dict(load_checkpoint(checkpoint_path),strict=True)
        self.model.to(self.device).eval()
        self.tokenizer = PromptTokenizer(bpe_path)
        self.batch_size = int(batch_size)
        if self.batch_size <= 0:
            raise ValueError('Batch size must be positive')
        self.weight = self.model.config.fusion_weight if fusion_weight is None else float(fusion_weight)
        self.method = self.model.config.attribute_score if attribute_score is None else attribute_score
        if self.method not in ('nll','agreement') or not np.isfinite(self.weight) or not 0<=self.weight<=1:
            raise ValueError('Invalid fusion configuration')

    @torch.inference_mode()
    def rank_gallery(self, sample):
        check_attribute_names(sample['attribute_names'])
        q = np.asarray(sample['queries'])
        if not len(sample['queries']):
            q = np.empty((0,40),dtype=np.int64)
        if q.ndim != 2 or q.shape[1]!=40 or not np.isin(q,(0,1)).all():
            raise ValueError('Queries must be binary [Q,40]')
        gallery = sample['gallery']
        output = np.empty((len(q),len(gallery)),dtype=np.float64)
        if not len(q) or not len(gallery):
            return {'similarities':output}
        text,images,logits = [],[],[]
        for start in range(0,len(q),self.batch_size):
            tokens = torch.tensor([encode_query(v,self.tokenizer).token_ids for v in q[start:start+self.batch_size]],device=self.device)
            text.append(self.model.encode_text(tokens).cpu())
        for batch in DataLoader(SampleGallery(gallery),batch_size=self.batch_size,shuffle=False,num_workers=0):
            f,z = self.model.encode_image_and_attributes(batch.to(self.device))
            images.append(f.cpu());logits.append(z.cpu())
            print('Gallery encoded %d/%d'%(sum(len(t) for t in images),len(gallery)),flush=True)
        text = F.normalize(torch.cat(text).float(),dim=1)
        images = F.normalize(torch.cat(images).float(),dim=1)
        logits = torch.cat(logits)
        for start in range(0,len(q),32):
            global_score = (text[start:start+32]@images.t()).numpy()
            nll,agreement = attribute_scores(q[start:start+32],logits)
            output[start:start+32] = fuse(global_score,nll if self.method=='nll' else agreement,self.weight)
        if not np.isfinite(output).all():
            raise ValueError('Nonfinite retrieval output')
        return {'similarities':output}
