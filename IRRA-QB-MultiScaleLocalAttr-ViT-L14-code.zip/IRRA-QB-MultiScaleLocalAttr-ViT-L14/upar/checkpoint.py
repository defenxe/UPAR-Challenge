"""Trusted local pure model state_dict loading; no optimizer/scheduler schema."""
from pathlib import Path
import inspect
import torch


def load_checkpoint(path):
    path=Path(path)
    options=dict(map_location='cpu')
    if 'weights_only' in inspect.signature(torch.load).parameters:options['weights_only']=True
    state=torch.load(str(path),**options)
    if not isinstance(state,dict) or not state or not all(torch.is_tensor(v) for v in state.values()):
        raise ValueError('Require pure model state_dict')
    return state
