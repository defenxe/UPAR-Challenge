"""QB SDM+MAP with one additional supervised local attribute branch."""
from dataclasses import dataclass
import inspect
import math
import torch
import torch.nn.functional as F
from model.clip_model import CLIP
from model.objectives import compute_attribute_sdm, compute_map
from .config import ModelConfig
from .model import UPARModel
from .local_branch import LocalAttributeBranch
from .masking import IGNORE_INDEX

ARCHITECTURE = 'qb-global-local-attribute-v1'


@dataclass
class LocalModelConfig(ModelConfig):
    attr_loss_weight: float = 0.5
    local_heads: int = 8
    fusion_weight: float = 0.0
    attribute_score: str = 'nll'


def load_artifact(path):
    # Trusted local experiment artifacts; compatible with the lab's PyTorch 1.12.
    options = {'map_location': 'cpu'}
    if 'weights_only' in inspect.signature(torch.load).parameters:
        options['weights_only'] = True
    return torch.load(path, **options)


class GlobalLocalModel(UPARModel):
    def __init__(self, clip_model, clip_config, config=None, with_map=True):
        config = config or LocalModelConfig()
        if not math.isfinite(config.attr_loss_weight) or config.attr_loss_weight < 0:
            raise ValueError('Attribute loss weight must be finite and nonnegative')
        if not math.isfinite(config.fusion_weight) or not 0 <= config.fusion_weight <= 1:
            raise ValueError('Fusion weight must be in [0,1]')
        if config.attribute_score not in ('nll', 'agreement'):
            raise ValueError('Unknown attribute score')
        super().__init__(clip_model, clip_config, config, with_map)
        with torch.random.fork_rng(devices=[]):
            self.local_branch = LocalAttributeBranch(self.embed_dim, config.local_heads)



    def local_from_tokens(self, image_tokens):
        if image_tokens.ndim != 3 or image_tokens.shape[1:] != (244, 768):
            raise ValueError('Expected CLIP [B,244,768] with CLS at position zero')
        return self.local_branch(image_tokens[:, 1:, :])[0]

    def encode_image_and_attributes(self, images):
        tokens = self.base_model.encode_image(images)
        return tokens[:, 0, :].float(), self.local_from_tokens(tokens)

    def forward(self, batch):
        if not self.training or not self.with_map:
            raise RuntimeError('Training forward requires train mode and MAP modules')
        images, token_ids = batch['images'], batch['caption_ids']
        image_tokens, text_tokens = self.base_model(images, token_ids)
        image_global = image_tokens[:, 0, :].float()
        eos_positions = token_ids.eq(49407).long().argmax(dim=1)
        text_global = text_tokens[torch.arange(len(token_ids), device=token_ids.device), eos_positions].float()
        # Exact existing QB global losses and MAP architecture.
        sdm_loss = compute_attribute_sdm(image_global, text_global, batch['attributes'], self.logit_scale)
        masked_tokens = self.base_model.encode_text(batch['map_ids'])
        fused = self.cross_former(masked_tokens, image_tokens, image_tokens)
        selected = batch['map_labels'].ne(IGNORE_INDEX)
        scores = self.mlm_head(fused[selected]).float()
        labels = batch['map_labels'][selected]
        map_loss = compute_map(scores, labels) * self.config.map_loss_weight
        accuracy = scores.argmax(-1).eq(labels).float().mean() if labels.numel() else scores.sum() * 0
        logits = self.local_from_tokens(image_tokens)
        attributes = batch['attributes']
        if attributes.shape != logits.shape or not ((attributes == 0) | (attributes == 1)).all():
            raise ValueError('Attribute BCE labels must be binary [B,40] in official order')
        bce = F.binary_cross_entropy_with_logits(logits.float(), attributes.float())
        return {'sdm_loss': sdm_loss, 'map_loss': map_loss, 'attr_bce': bce,
                'attr_loss': self.config.attr_loss_weight * bce, 'attribute_logits': logits,
                'map_acc': accuracy, 'map_tokens': selected.sum(),
                'temperature': self.logit_scale.reciprocal()}

