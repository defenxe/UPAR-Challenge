import hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]


def implementation_hash():
    digest=hashlib.sha256()
    files=sorted(p for directory in ('upar','model','solver','datasets','utils','tests')
                 for p in (ROOT/directory).glob('*.py'))
    for path in files:
        digest.update(str(path.relative_to(ROOT)).encode());digest.update(b'\0');digest.update(path.read_bytes())
    return digest.hexdigest()


def config_hash(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
