"""Run numerical verification before any actual batch-32 training."""
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from .audit import implementation_hash,config_hash
from .local_validation import KST
ROOT=Path(__file__).resolve().parents[1]


def verify_evidence(directory,config,gpu=None):
    directory=Path(directory)
    for name,key,expected in (('gradient_cache_gpu.json','passed',True),('gpu_preflight.json','status','passed')):
        result=json.loads((directory/name).read_text())
        if result.get(key)!=expected:raise RuntimeError('Required preflight did not pass: '+name)
        if result.get('implementation_hash')!=implementation_hash() or result.get('config_hash')!=config_hash(config):
            raise RuntimeError('Preflight evidence is stale: '+name)
        if gpu and result['gpu']['uuid']!=gpu['uuid']:raise RuntimeError('Preflight was performed on another GPU')


def ensure_preflight(args):
    if args.preflight_dir:
        verify_evidence(args.preflight_dir,args.config)
        return
    output=args.output_dir or ROOT/('smoke_runs' if args.smoke_test_steps else 'experiments')
    directory=Path(output).resolve()/('preflight_'+datetime.now(KST).strftime('%Y%m%d_%H%M%S_%f_KST'))
    directory.mkdir(parents=True,exist_ok=False)
    common=['--data-root',str(args.data_root),'--config',str(args.config),'--report-dir',str(directory)]
    if args.gpu_device is not None:common+=['--gpu-device',str(args.gpu_device)]
    if args.pretrained is not None:common+=['--pretrained',str(args.pretrained)]
    for script in ('verify_gradient_cache.py','gpu_preflight.py'):
        with (directory/(script+'.log')).open('w') as stream:
            subprocess.run([sys.executable,'-u',str(ROOT/'tests'/script)]+common,
                           stdout=stream,stderr=subprocess.STDOUT,check=True,cwd=str(ROOT))
    args.preflight_dir=directory
    verify_evidence(directory,args.config)
