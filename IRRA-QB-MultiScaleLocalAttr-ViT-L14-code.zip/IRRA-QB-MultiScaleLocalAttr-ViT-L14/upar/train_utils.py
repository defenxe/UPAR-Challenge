import os, sys, json, hashlib, random, math
from pathlib import Path
import numpy as np
import torch

class Tee:
    def __init__(self, console, path):
        self.console, self.file = console, Path(path).open('a', buffering=1)

    def write(self, text):
        self.console.write(text)
        self.file.write(text)

    def flush(self):
        self.console.flush()
        self.file.flush()

    def close(self):
        self.file.flush()
        self.file.close()

def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False))
    temporary.replace(path)

def check_epoch_weight_slots(directory):
    """Refuse to reuse any of the ten protected epoch-weight filenames."""
    directory = Path(directory)
    conflicts = [directory / ('epoch_%03d.pth' % epoch)
                 for epoch in range(1, 11)
                 if (directory / ('epoch_%03d.pth' % epoch)).exists()]
    if conflicts:
        raise FileExistsError('Refusing to overwrite existing epoch weights: ' +
                              ', '.join(str(path) for path in conflicts))

def save_epoch_state_dict(model, epoch, directory):
    """Save only the unwrapped model state_dict for completed epochs 1 through 10."""
    if not 1 <= epoch <= 10:
        raise ValueError('Epoch state_dict export is limited to completed epochs 1-10')
    directory = Path(directory)
    path = directory / ('epoch_%03d.pth' % epoch)
    base_model = model.module if hasattr(model, 'module') else model
    # O_EXCL protects an existing file even if another run races the preflight.
    descriptor = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            torch.save(base_model.state_dict(), stream)
    except Exception:
        try:
            path.unlink()
        except OSError:
            pass
        raise
    return path

def verify_epoch_state_dict(model, path):
    """Verify a saved epoch export contains exactly the live model state."""
    state = torch.load(str(path), map_location='cpu')
    if not isinstance(state, dict) or not state:
        raise RuntimeError('Epoch checkpoint is not a nonempty state_dict: ' + str(path))
    live = model.state_dict()
    if set(state) != set(live):
        raise RuntimeError('Epoch checkpoint keys do not match the model: ' + str(path))
    for name, expected in live.items():
        actual = state[name]
        if (not torch.is_tensor(actual) or actual.shape != expected.shape or
                actual.dtype != expected.dtype or not torch.equal(actual, expected.detach().cpu())):
            raise RuntimeError('Epoch checkpoint tensor mismatch: ' + name)
    # Strictly reload the verified pure state_dict before treating it as valid.
    model.load_state_dict(state, strict=True)
    return {'path': str(path), 'bytes': Path(path).stat().st_size,
            'sha256': digest(path), 'tensor_count': len(state),
            'strict_load': True, 'matches_live_model': True,
            'keys': len(state)}

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 ** 2), b''):
            h.update(chunk)
    return h.hexdigest()

def seed_all(value):
    random.seed(value)
    np.random.seed(value)
    torch.manual_seed(value)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(value)

def joint_groups(model):
    """All image/text/MAP/local parameters are active from the first update."""
    model.requires_grad_(True)
    groups = {name: [] for name in ('image', 'text', 'map', 'local', 'multiscale')}
    for name, parameter in model.named_parameters():
        group = ('multiscale' if name.startswith('multiscale.') else
                 'local' if name.startswith('local_branch.') else
                 'image' if name.startswith('base_model.visual.') else
                 'text' if name.startswith('base_model.') else 'map')
        groups[group].append((name, parameter))
    ids = [id(p) for items in groups.values() for _, p in items]
    if len(ids) != len(set(ids)) or len(ids) != len(list(model.parameters())):
        raise AssertionError('Missing or duplicated optimizer parameter')
    if any(not items for items in groups.values()):
        raise AssertionError('Empty training module group')
    return groups

def optimizer_for(model, train_config, local_lr):
    groups = joint_groups(model)
    optimizer = torch.optim.Adam(
        [{'params': [p for _, p in items], 'name': name,
          'lr': local_lr if name in ('local', 'multiscale') else train_config.lr}
         for name, items in groups.items()],
        betas=(train_config.alpha, train_config.beta), eps=train_config.adam_eps,
        weight_decay=train_config.weight_decay)
    return optimizer, groups

def gradient_report(model, groups, allow_zero=False):
    norms = {}
    for group, items in groups.items():
        squared = torch.zeros((), device=next(model.parameters()).device)
        for name, p in items:
            if p.grad is None or not torch.isfinite(p.grad).all():
                raise FloatingPointError('Missing/nonfinite gradient: ' + name)
            squared += p.grad.detach().square().sum()
        norms[group] = float(squared.sqrt())
        if not math.isfinite(norms[group]) or (norms[group] <= 0 and not allow_zero):
            raise FloatingPointError('No finite nonzero gradient in ' + group)
    return norms

def method_weight(name, validation):
    if name == 'Global-only':
        return 0.0
    if name.endswith('-only'):
        return 1.0
    if name == 'Global+NLL-fixed0.40':
        return 0.4
    return validation['best_weights']['nll' if name == 'Global+NLL' else 'agreement']
