"""Portable inference image dataset, using the same 378 x 126 CLIP transform."""
from torch.utils.data import Dataset
from .images import image_transform,read_rgb


class SampleGallery(Dataset):
    def __init__(self,gallery):self.gallery=gallery;self.transform=image_transform()
    def __len__(self):return len(self.gallery)
    def __getitem__(self,index):return self.transform(read_rgb(self.gallery[index]['image_path']))


def RetrievalEngine(*args,**kwargs):
    from .local_inference import LocalRetrievalEngine
    kwargs.setdefault('fusion_weight',0.)
    return LocalRetrievalEngine(*args,**kwargs)
