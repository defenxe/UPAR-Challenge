"""Portable single-GPU checks and bounded FP32 allocation."""
import csv
import ctypes
import threading
import io
import os
import subprocess
import torch
from .precision import configure_fp32


def gpu_inventory():
    result = subprocess.run(['nvidia-smi','--query-gpu=name,uuid,pci.bus_id,memory.total,memory.used',
                             '--format=csv,noheader,nounits'],stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,universal_newlines=True,timeout=60,check=True)
    return [dict(name=r[0].strip(),uuid=r[1].strip(),pci_bus_id=r[2].strip(),
                 total_memory_mib=int(r[3]),used_memory_mib=int(r[4]))
            for r in csv.reader(io.StringIO(result.stdout)) if r]


def prepare_gpu(gpu_device, max_reserved_mib):
    # Set visibility before the first CUDA API; leave Kubernetes' inherited mapping intact by default.
    if gpu_device is not None:
        os.environ['CUDA_VISIBLE_DEVICES'] = str(gpu_device)
    configure_fp32()
    rows = gpu_inventory()
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError('Expose exactly one GPU using --gpu-device or CUDA_VISIBLE_DEVICES')
    device = torch.device('cuda:0')
    props = torch.cuda.get_device_properties(device)
    # Bind NVML evidence to the CUDA device, including hosts with multiple exposed NVML devices.
    visible = os.environ.get('CUDA_VISIBLE_DEVICES','')
    driver=ctypes.CDLL('libcuda.so.1')
    cuda_device=ctypes.c_int()
    if driver.cuDeviceGet(ctypes.byref(cuda_device),0)!=0:raise RuntimeError('cuDeviceGet failed')
    raw_uuid=(ctypes.c_ubyte*16)()
    if driver.cuDeviceGetUuid(ctypes.byref(raw_uuid),cuda_device)!=0:raise RuntimeError('cuDeviceGetUuid failed')
    hex_uuid=bytes(raw_uuid).hex()
    cuda_uuid='GPU-'+ '-'.join((hex_uuid[:8],hex_uuid[8:12],hex_uuid[12:16],hex_uuid[16:20],hex_uuid[20:]))
    selected = [r for r in rows if r['uuid'] == cuda_uuid]
    if len(selected)!=1 or selected[0]['name']!=props.name:
        raise RuntimeError('CUDA/NVML device identification mismatch')
    gpu = selected[0]
    # Occupied devices are left untouched. A fresh context can consume ~300 MiB.
    if gpu['used_memory_mib'] > 512:
        raise RuntimeError('Selected GPU is already occupied; no other process is changed')
    if max_reserved_mib > 9600 or max_reserved_mib <= 0:
        raise ValueError('Memory budget must be positive and at most 9600 MiB')
    torch.cuda.set_per_process_memory_fraction(min(max_reserved_mib*1024**2/props.total_memory,1),device)
    gpu.update(cuda_device='cuda:0',compute_capability=list(torch.cuda.get_device_capability(device)),
               allocator_budget_mib=max_reserved_mib,rtx_2080_ti_test=props.name.endswith('RTX 2080 Ti'))
    return device,gpu


def memory_report(gpu):
    torch.cuda.synchronize()
    result = dict(peak_allocated_mib=torch.cuda.max_memory_allocated()/1024**2,
                  peak_reserved_mib=torch.cuda.max_memory_reserved()/1024**2,
                  allocated_mib=torch.cuda.memory_allocated()/1024**2,
                  reserved_mib=torch.cuda.memory_reserved()/1024**2)
    rows = [r for r in gpu_inventory() if r['uuid']==gpu['uuid']]
    if len(rows)!=1: raise RuntimeError('GPU disappeared from NVML inventory')
    result['total_gpu_used_mib'] = rows[0]['used_memory_mib']
    return result


class GPUMonitor:
    """NVML sampling of this GPU, including CUDA context and allocator overhead."""
    def __init__(self,gpu):
        self.peak_used_mib=0;self.samples=0;self.error=None
        self.process=subprocess.Popen(['nvidia-smi','--id='+gpu['uuid'],
            '--query-gpu=memory.used','--format=csv,noheader,nounits','--loop-ms=200'],
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True,bufsize=1)
        self.thread=threading.Thread(target=self._read,daemon=True);self.thread.start()
    def _read(self):
        try:
            for line in self.process.stdout:
                self.peak_used_mib=max(self.peak_used_mib,int(line.strip()));self.samples+=1
        except Exception as error:self.error=str(error)
    def stop(self):
        self.process.terminate();self.process.wait(timeout=30);self.thread.join(timeout=5)
        self.process.stdout.close();self.process.stderr.close()
        if self.error or not self.samples:raise RuntimeError('NVML monitor failed: '+str(self.error))
        return dict(peak_total_gpu_used_mib=self.peak_used_mib,nvml_samples=self.samples,nvml_interval_ms=200)
