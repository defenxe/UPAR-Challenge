"""Standalone original Global/Local validation of a pure epoch state_dict."""
import argparse
from pathlib import Path
import torch
from upar.full_training import ROOT,load_config
from upar.multiscale_model import MultiScaleLocalModel
from upar.pretrained import CLIP_CONFIG
from model.clip_model import CLIP
from upar.checkpoint import load_checkpoint
from upar.data import UPARSplit,validation_loaders
from upar.tokenizer import PromptTokenizer
from upar.runtime import prepare_gpu
from upar.local_validation import evaluate_local


def main():
    p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--data-root',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--gpu-device');p.add_argument('--config',type=Path,default=ROOT/'configs/train_fp32.json')
    a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1)
    cfg,tc,mc=load_config(a.config);device,gpu=prepare_gpu(a.gpu_device,cfg['memory']['max_reserved_mib'])
    model=MultiScaleLocalModel(CLIP(**CLIP_CONFIG),dict(CLIP_CONFIG),mc,with_map=True).float()
    model.load_state_dict(load_checkpoint(a.checkpoint),strict=True);model.to(device).eval()
    tokenizer=PromptTokenizer();val=UPARSplit.read(a.data_root,'val');train=UPARSplit.read(a.data_root,'train')
    gallery,queries=validation_loaders(val,tokenizer,tc.test_batch_size,tc.num_workers)
    evaluate_local(model,gallery,queries,a.output_dir,set(train.queries),micro_batch_size=cfg['memory']['evaluation_micro_batch_size'])
    model=gallery=queries=None
    import gc
    gc.collect();torch.cuda.empty_cache()

if __name__=='__main__':main()
