"""Run the actual orchestration on a small CPU fixture to verify fixed termination."""
import argparse
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
sys.path.insert(0,str(Path(__file__).resolve().parent))
import torch
from torch.utils.data import DataLoader,Dataset,SequentialSampler
from test_core import Tiny,batch
import upar.full_training as training


class Toy(Tiny):
    def __init__(self):
        super().__init__();self.initialization_report={};self.config=SimpleNamespace(fusion_weight=0.)
    def gradient_checkpointing(self,*args):pass


class Samples(Dataset):
    def __init__(self):self.data=batch(64);self.split=SimpleNamespace(queries=(tuple(self.data['attributes'][0].tolist()),))
    def __len__(self):return 64
    def __getitem__(self,i):return {k:v[i] for k,v in self.data.items()}


class Sampler(SequentialSampler):
    def set_epoch(self,e):pass
    def metadata(self):return dict(type='test_fixture')


class Monitor:
    def __init__(self,*args):pass
    def stop(self):return dict(peak_total_gpu_used_mib=0,nvml_samples=1)


class Lifecycle(unittest.TestCase):
    def exercise(self,smoke):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root);pretrained=path/'test.pt';pretrained.write_bytes(b'fixture')
            args=argparse.Namespace(config=training.ROOT/'configs/train_fp32.json',smoke_test_steps=smoke,
                pretrained=pretrained,data_root=path,output_dir=path,gpu_device=None,preflight_dir=path)
            ds=Samples();loader=DataLoader(ds,batch_size=32,sampler=Sampler(ds),generator=torch.Generator())
            events=[]
            def loaders(*args):return loader,None,None
            def optimizer(model,tc,lr):return torch.optim.Adam([dict(params=list(model.parameters()),name='all')],lr=tc.lr,eps=tc.adam_eps),{'all':list(model.named_parameters())}
            update=training.optimizer_update
            def tracked_update(*args):events.append('update');return update(*args)
            save=training.save_epoch_state_dict
            def tracked_save(model,epoch,out):events.append('save_%d'%epoch);return save(model,epoch,out)
            verify=training.verify_epoch_state_dict
            def tracked_verify(*args):events.append('reload');return verify(*args)
            def validation(*args,**kwargs):
                events.append('validation');return dict(methods={'Global+NLL':{'mADM':.5}},best_weights={'nll':.4})
            with patch.object(training,'prepare_gpu',return_value=(torch.device('cpu'),{})), \
                 patch.object(training,'verify_evidence'),patch.object(training,'GPUMonitor',Monitor), \
                 patch.object(training.MultiScaleLocalModel,'from_local_pretrained',side_effect=lambda *a:Toy()), \
                 patch.object(training,'training_loaders',side_effect=loaders),patch.object(training,'check_protocol'), \
                 patch.object(training,'optimizer_for',side_effect=optimizer), \
                 patch.object(training,'optimizer_update',side_effect=tracked_update), \
                 patch.object(training,'evaluate_local',side_effect=validation), \
                 patch.object(training,'save_epoch_state_dict',side_effect=tracked_save), \
                 patch.object(training,'verify_epoch_state_dict',side_effect=tracked_verify), \
                 patch.object(training,'memory_report',return_value={}), \
                 patch.object(torch,'set_num_interop_threads'),patch.object(torch.cuda,'reset_peak_memory_stats'), \
                 patch.object(torch.cuda,'max_memory_allocated',return_value=0), \
                 patch.object(torch.cuda,'max_memory_reserved',return_value=0), \
                 patch.object(torch.cuda,'is_initialized',return_value=False):
                output=training.run(args)
            status=json.loads((output/'status.json').read_text());self.assertTrue(status['normal_exit'])
            self.assertFalse(status['epoch_11_started'])
            if smoke:
                self.assertEqual(events,['update']);self.assertEqual(status['completed_full_epochs'],0)
                self.assertEqual(list(output.glob('*.pth')),[]);self.assertEqual(status['current_epoch'],1)
            else:
                expected=[]
                for e in range(1,11):expected+=['update','update','validation','save_%d'%e,'reload']
                expected+=['reload'];self.assertEqual(events,expected)
                self.assertEqual(status['completed_full_epochs'],10)
                self.assertEqual({p.name for p in output.glob('*.pth')},{'epoch_%03d.pth'%e for e in range(1,11)})
            return dict(smoke_steps=smoke,events=events,status=status)
    def test_epoch10_and_smoke(self):
        results=[self.exercise(0),self.exercise(1)]
        (training.ROOT/'reports/lifecycle_tests.json').write_text(json.dumps(dict(passed=True,GPU_test=False,results=results),indent=2))

if __name__=='__main__':unittest.main()
