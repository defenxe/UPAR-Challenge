import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
from torch import nn
from model.objectives import compute_attribute_sdm,compute_map
from model.recompute import recompute_block
from solver import build_lr_scheduler
from upar.full_training import load_config,ROOT
from upar.config import TrainConfig
from upar.multiscale_model import MultiScaleModelConfig,WeightedPatchFusion
from upar.gradient_cache import backward_effective_batch
from upar.precision import configure_fp32
from upar.train_utils import save_epoch_state_dict,verify_epoch_state_dict


class Tiny(nn.Module):
    def __init__(self):
        super().__init__()
        self.image=nn.Linear(6,8);self.text=nn.Embedding(32,8)
        self.multiscale=nn.Linear(8,8);self.local_branch=nn.Linear(8,40)
        self.map_head=nn.Linear(16,32)
        self.register_buffer('logit_scale',torch.tensor(5.))
        self.checkpointing=False
    def global_features(self,b):
        image=recompute_block(self.image,b['images']) if self.checkpointing else self.image(b['images'])
        text=self.text(b['caption_ids']).mean(1)
        return image,text,image[:,None,:]
    def auxiliary_result(self,b,features):
        tokens=self.text(b['map_ids']);image=features.expand(-1,len(tokens[0]),-1)
        select=b['map_labels']!=-100;labels=b['map_labels'][select]
        scores=self.map_head(torch.cat((tokens,image),-1)[select])
        logits=self.local_branch(self.multiscale(features[:,0]).tanh())
        bce=nn.functional.binary_cross_entropy_with_logits(logits,b['attributes'].float())
        return dict(map_loss=compute_map(scores,labels),map_tokens=select.sum(),map_correct=scores.argmax(-1).eq(labels).sum(),
                    attr_bce=bce,attr_loss=bce*.5)
    def forward(self,b):
        i,t,f=self.global_features(b);r=self.auxiliary_result(b,f)
        r['sdm_loss']=compute_attribute_sdm(i,t,b['attributes'],self.logit_scale)
        return r


def batch(n,no_map=False):
    gen=torch.Generator().manual_seed(17)
    ids=torch.randint(1,31,(n,4),generator=gen);labels=torch.full_like(ids,-100)
    for k in range(n):
        if not no_map:labels[k,:k%4]=ids[k,:k%4]
    return dict(images=torch.randn(n,6,generator=gen),caption_ids=ids,map_ids=ids.clone(),map_labels=labels,
                attributes=torch.randint(0,2,(n,40),generator=gen))


class Core(unittest.TestCase):
    @classmethod
    def setUpClass(cls):configure_fp32();torch.set_num_threads(1)
    def test_full_batch_32_partial_5_and_zero_MAP(self):
        for n,micro,no_map in ((32,4,False),(5,2,False),(5,1,True)):
            torch.manual_seed(1);full=Tiny();cache=copy.deepcopy(full);data=batch(n,no_map)
            result=full(data);loss=sum(result[k] for k in ('sdm_loss','map_loss','attr_loss'));loss.backward()
            got=backward_effective_batch(cache,data,micro)
            torch.testing.assert_close(torch.tensor(got['loss']),loss.detach(),rtol=2e-6,atol=2e-6)
            self.assertEqual(got['sdm_matrix_shape'],[n,n])
            for (name,p),(_,q) in zip(full.named_parameters(),cache.named_parameters()):
                self.assertIsNotNone(q.grad,name);torch.testing.assert_close(p.grad,q.grad,rtol=3e-5,atol=3e-6)
            a=torch.optim.Adam(full.parameters(),lr=1e-5,eps=.001,weight_decay=4e-5)
            b=torch.optim.Adam(cache.parameters(),lr=1e-5,eps=.001,weight_decay=4e-5)
            a.step();b.step()
            for p,q in zip(full.parameters(),cache.parameters()):torch.testing.assert_close(p,q,rtol=2e-6,atol=2e-7)
    def test_recompute_gradient(self):
        torch.manual_seed(8);a=Tiny();b=copy.deepcopy(a);b.checkpointing=True
        data=batch(5);data['images'].requires_grad_(True)
        x=a(data);y=b(data)
        sum(x[k] for k in ('sdm_loss','map_loss','attr_loss')).backward()
        sum(y[k] for k in ('sdm_loss','map_loss','attr_loss')).backward()
        for p,q in zip(a.parameters(),b.parameters()):torch.testing.assert_close(p.grad,q.grad,rtol=1e-6,atol=1e-7)
    def test_schedule_first_ten_identical(self):
        cfg,tc,mc=load_config(ROOT/'configs/train_fp32.json')
        base=TrainConfig(**json.loads((ROOT/'reports/baseline_config.json').read_text())['train'])
        a=torch.optim.Adam([torch.nn.Parameter(torch.ones(1))],lr=tc.lr)
        b=torch.optim.Adam([torch.nn.Parameter(torch.ones(1))],lr=base.lr)
        sa=build_lr_scheduler(tc,a);sb=build_lr_scheduler(base,b)
        trace=[]
        for epoch in range(1,11):
            self.assertEqual(sa.get_last_lr(),sb.get_last_lr());trace.append(dict(epoch=epoch,backbone_lr=sa.get_last_lr()[0],local_lr=sa.get_last_lr()[0]*10))
            a.step();b.step();sa.step();sb.step()
        (ROOT/'reports/lr_first10.json').write_text(json.dumps(trace,indent=2))
    def test_checkpoint_policy(self):
        m=Tiny()
        with tempfile.TemporaryDirectory() as d:
            for epoch in range(1,11):
                path=save_epoch_state_dict(m,epoch,d);verify_epoch_state_dict(m,path)
            self.assertEqual(len(list(Path(d).glob('*.pth'))),10)
            with self.assertRaises(FileExistsError):save_epoch_state_dict(m,10,d)
            with self.assertRaises(ValueError):save_epoch_state_dict(m,11,d)
    def test_multiscale_shapes_and_gradient(self):
        fusion=WeightedPatchFusion((.2,.2,.6))
        intermediate={k:torch.randn(2,243,1024,requires_grad=True) for k in (8,16)}
        final=torch.randn(2,244,768,requires_grad=True)
        output=fusion(intermediate,final);self.assertEqual(tuple(output.shape),(2,243,768))
        output.square().mean().backward()
        for v in list(intermediate.values())+list(fusion.parameters()):self.assertTrue(torch.isfinite(v.grad).all())
        self.assertTrue(final.grad[:,0].eq(0).all())

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Core))
    (ROOT/'reports/unit_tests.json').write_text(json.dumps(dict(passed=result.wasSuccessful(),tests=result.testsRun,
                                    errors=len(result.errors),failures=len(result.failures)),indent=2))
    sys.exit(0 if result.wasSuccessful() else 1)
