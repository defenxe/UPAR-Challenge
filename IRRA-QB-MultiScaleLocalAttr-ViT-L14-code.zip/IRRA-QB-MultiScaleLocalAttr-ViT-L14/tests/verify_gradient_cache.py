"""Controlled FP32 full-batch vs cache gradients, all branches and Adam updates."""
import gc
import json
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
from upar.full_training import ROOT, load_config, check_protocol
from upar.train_utils import seed_all, optimizer_for, gradient_report, write_json
from upar.multiscale_model import MultiScaleLocalModel
from upar.tokenizer import PromptTokenizer
from upar.data import training_loaders
from upar.gradient_cache import backward_effective_batch
from upar.precision import assert_model_fp32, assert_optimizer_fp32
from solver import build_lr_scheduler
from upar.runtime import prepare_gpu, memory_report
from upar.audit import implementation_hash, config_hash


def compare(model,batch,tc,local_lr,micro):
    initial={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    model.train();model.gradient_checkpointing(True)
    device=next(model.parameters()).device
    full={k:v.to(device) for k,v in batch.items()}
    optimizer,groups=optimizer_for(model,tc,local_lr)
    scheduler=build_lr_scheduler(tc,optimizer)
    optimizer.zero_grad(set_to_none=True)
    rng=torch.get_rng_state();cuda_rng=torch.cuda.get_rng_state(device)
    result=model(full)
    total=result['sdm_loss']+result['map_loss']+result['attr_loss']
    print('Full-batch backward',flush=True)
    total.backward(); gradient_report(model,groups);assert_model_fp32(model,True)
    losses={k:float(result[k].detach()) for k in ('sdm_loss','map_loss','attr_loss','attr_bce')}
    losses['loss']=float(total.detach())
    reference={k:p.grad.detach().cpu().clone() for k,p in model.named_parameters()}
    print('Adam step',flush=True)
    optimizer.step();assert_optimizer_fp32(optimizer)
    updated={k:p.detach().cpu().clone() for k,p in model.named_parameters()}
    optimizer.zero_grad(set_to_none=True)
    del result,total,scheduler,optimizer,full,groups
    gc.collect();torch.cuda.empty_cache()
    model.load_state_dict(initial,strict=True);del initial
    torch.set_rng_state(rng);torch.cuda.set_rng_state(cuda_rng,device)
    optimizer,groups=optimizer_for(model,tc,local_lr)
    scheduler=build_lr_scheduler(tc,optimizer)
    print('Cache backward',flush=True)
    cached=backward_effective_batch(model,batch,micro)
    coverage=gradient_report(model,groups)
    for k,v in losses.items():
        torch.testing.assert_close(torch.tensor(cached[k]),torch.tensor(v),rtol=2e-5,atol=2e-5)
    errors={}; group_errors={k:[0.,0.,0.] for k in groups}
    for group,items in groups.items():
        for name,p in items:
            got=p.grad.detach().cpu();ref=reference.pop(name)
            if not torch.allclose(got,ref,rtol=3e-3,atol=3e-5):
                print('ELEMENT_DIAGNOSTIC '+name+' max_abs='+str(float((got-ref).abs().max()))+' ref_max='+str(float(ref.abs().max())),flush=True)
            difference=(got-ref).double();ref64=ref.double()
            group_errors[group][0]+=float(difference.square().sum())
            group_errors[group][1]+=float(ref64.square().sum())
            group_errors[group][2]=max(group_errors[group][2],float(difference.abs().max()))
    for group,(err,norm,maximum) in group_errors.items():
        rel=(err/max(norm,1e-30))**.5
        print('GRADIENT_GROUP '+group+' relative_l2='+str(rel)+' max_abs='+str(maximum),flush=True)
        if rel>2e-4:raise AssertionError('Gradient relative L2: '+group+' '+str(rel))
        errors[group]=dict(relative_l2=rel,max_absolute_error=maximum,gradient_norm=coverage[group])
    print('Adam step',flush=True)
    optimizer.step();assert_optimizer_fp32(optimizer)
    update_error=0.;update_errors={}
    for name,p in model.named_parameters():
        got=p.detach().cpu();ref=updated.pop(name)
        error=float((got-ref).abs().max())
        update_errors[name]=error
        if not torch.allclose(got,ref,rtol=2e-5,atol=2e-6):
            print('ADAM_DIAGNOSTIC '+name+' max_abs='+str(error),flush=True)
        torch.testing.assert_close(got,ref,rtol=2e-5,atol=2e-6)
        update_error=max(update_error,float((got-ref).abs().max()))
    optimizer.zero_grad(set_to_none=True)
    lrs={g['name']:g['lr'] for g in optimizer.param_groups}
    del scheduler,optimizer,groups
    gc.collect();torch.cuda.empty_cache()
    return dict(passed=True,batch_size=len(batch['images']),micro_batch_size=micro,
                full_batch_losses=losses,cache_losses=cached,gradient_comparisons=errors,
                optimizer_update_max_abs_error=update_error,optimizer_lrs=lrs,
                optimizer_parameter_max_errors=update_errors,
                controlled_rng=True,controlled_masks=True,identical_initial_weights=True,
                tolerances=dict(loss_rtol=2e-5,loss_atol=2e-5,gradient_rtol=3e-3,
                                gradient_atol='diagnostic only; normalized L2 is acceptance criterion',gradient_relative_l2=2e-4,adam_atol=2e-6,adam_rtol=2e-5))


def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--data-root',type=Path,required=True)
    parser.add_argument('--gpu-device')
    parser.add_argument('--config',type=Path,default=ROOT/'configs/train_fp32.json')
    parser.add_argument('--pretrained',type=Path)
    parser.add_argument('--report-dir',type=Path,default=ROOT/'reports')
    args=parser.parse_args();args.report_dir.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    config,tc,mc=load_config(args.config)
    device,gpu=prepare_gpu(args.gpu_device,config['memory']['max_reserved_mib'])
    seed_all(tc.seed)
    tokenizer=PromptTokenizer();loader,gallery,queries=training_loaders(args.data_root,tokenizer,tc)
    check_protocol(loader,gallery,queries)
    iterator=iter(loader);batch=next(iterator);del iterator
    small={k:v[:2] for k,v in batch.items()}
    model=MultiScaleLocalModel.from_local_pretrained((args.pretrained or ROOT/config['pretrained']),mc).to(device)
    torch.cuda.reset_peak_memory_stats()
    print('Actual ViT-L/14 full batch 2 versus micro batch 1 comparison starting',flush=True)
    result=compare(model,small,tc,config['local_lr'],1)
    result.update(gpu=gpu,memory=memory_report(gpu),sampling=loader.sampler.metadata(),
                  implementation_hash=implementation_hash(),config_hash=config_hash(args.config))
    write_json(args.report_dir/'gradient_cache_gpu.json',result)
    print(json.dumps(result,indent=2),flush=True)
    model=loader=gallery=queries=None;gc.collect();torch.cuda.empty_cache()
    print('NORMAL_EXIT allocated_bytes='+str(torch.cuda.memory_allocated()),flush=True)

if __name__=='__main__':main()
