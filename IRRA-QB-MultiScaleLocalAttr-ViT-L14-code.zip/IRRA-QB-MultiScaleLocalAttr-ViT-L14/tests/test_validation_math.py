import tempfile,unittest
from pathlib import Path
import numpy as np
from upar.local_validation import _init_sweep,_chunk,WORKER
from upar.local_scoring import fuse,stable_rank
from upar.metrics import metrics_for_ranking


class SweepTests(unittest.TestCase):
    def test_sweep_madm_matches_official_every_pair(self):
        q=np.zeros((3,40),dtype=np.int64);q[1,0]=1;q[2,1]=1
        gallery=np.concatenate([q,q[:2],q[1:2]],axis=0)
        rng=np.random.RandomState(7)
        scores={m:rng.randn(len(q),len(gallery)) for m in ('global','nll','agreement')}
        grid={'nll':[0.,.5,1.],'agreement':[0.,.5,1.]}
        root=Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory(dir=str(root/'reports')) as directory:
            for name,a in scores.items():np.save(str(Path(directory)/(name+'_scores.npy')),a)
            _init_sweep(directory,q,gallery,grid)
            _,_,result=_chunk(0,len(q))
            for m,weights in grid.items():
                for w in weights:
                    rank=stable_rank(fuse(scores['global'],scores[m],w))
                    for i in range(len(q)):
                        self.assertAlmostEqual(result[(m,w)][i],metrics_for_ranking(rank[i],q[i],gallery)['mADM'],places=13)
            # Close mappings before removing files on the shared NFS filesystem.
            for mapping in WORKER['scores'].values():
                mapping._mmap.close()
            WORKER.clear()
