"""Actual dataset batch 32 FP32 update, strict weight round-trip, validation forward."""
import argparse
import gc
import json
import os
import sys
import tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
from upar.full_training import ROOT,load_config,check_protocol
from upar.multiscale_model import MultiScaleLocalModel
from upar.tokenizer import PromptTokenizer
from upar.data import training_loaders
from upar.train_utils import seed_all,optimizer_for,gradient_report,write_json,verify_epoch_state_dict
from upar.gradient_cache import optimizer_update
from upar.runtime import prepare_gpu,memory_report,GPUMonitor
from upar.audit import implementation_hash, config_hash
from upar.precision import assert_model_fp32
from solver import build_lr_scheduler


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data-root',type=Path,required=True)
    parser.add_argument('--gpu-device')
    parser.add_argument('--config',type=Path,default=ROOT/'configs/train_fp32.json')
    parser.add_argument('--pretrained',type=Path)
    parser.add_argument('--report-dir',type=Path,default=ROOT/'reports')
    args=parser.parse_args();args.report_dir.mkdir(parents=True,exist_ok=True)
    result=dict(status='running');monitor=None
    try:
        cache=json.loads((args.report_dir/'gradient_cache_gpu.json').read_text())
        if cache.get('passed') is not True:raise RuntimeError('Actual-model gradient equivalence must pass first')
        torch.set_num_threads(1);torch.set_num_interop_threads(1)
        config,tc,mc=load_config(args.config)
        device,gpu=prepare_gpu(args.gpu_device,config['memory']['max_reserved_mib'])
        monitor=GPUMonitor(gpu)
        seed_all(tc.seed)
        model=MultiScaleLocalModel.from_local_pretrained((args.pretrained or ROOT/config['pretrained']),mc)
        result['pretrained']=model.initialization_report
        model.gradient_checkpointing(True);model.to(device).train()
        optimizer,groups=optimizer_for(model,tc,config['local_lr'])
        scheduler=build_lr_scheduler(tc,optimizer)
        tokenizer=PromptTokenizer();loader,gallery,queries=training_loaders(args.data_root,tokenizer,tc)
        check_protocol(loader,gallery,queries)
        result.update(gpu=gpu,config=str(ROOT/'configs/train_fp32.json'),data_root=str(args.data_root),
                      sampler=loader.sampler.metadata(),train_images=len(loader.dataset),
                      val_gallery=len(gallery.dataset),val_queries=len(queries.dataset),
                      precision='FP32',AMP=False,TF32=False)
        iterator=iter(loader);batch=next(iterator);del iterator
        torch.cuda.reset_peak_memory_stats()
        print('Full effective batch 32 cache update starting',flush=True)
        result['update']=optimizer_update(model,optimizer,batch,config['memory']['micro_batch_size'])
        result['gradients']=gradient_report(model,groups)
        assert_model_fp32(model,True)
        result['memory']=memory_report(gpu)
        optimizer.zero_grad(set_to_none=True)
        fd,path=tempfile.mkstemp(prefix='test_only_roundtrip_',suffix='.pth',dir=str(args.report_dir))
        try:
            with os.fdopen(fd,'wb') as stream:torch.save(model.state_dict(),stream)
            result['temporary_weight']=verify_epoch_state_dict(model,Path(path))
            result['temporary_weight']['test_only']=True
        finally:Path(path).unlink()
        model.eval()
        with torch.no_grad():
            images=next(iter(gallery))[1][:2].to(device)
            attrs,tokens=next(iter(queries));tokens=tokens[:2].to(device)
            image,scales=model.image_tokens_and_scales(images)
            logits=model.local_from_tokens(image,scales);text=model.encode_text(tokens)
            result['validation_shapes']=dict(image_tokens=list(image.shape),text=list(text.shape),
                    attributes=list(logits.shape),intermediate={str(k):list(v.shape) for k,v in scales.items()})
            if not all(torch.isfinite(v).all() for v in (image,logits,text)):raise FloatingPointError('Validation nonfinite')
            if image.shape!=(2,244,768) or text.shape!=(2,768) or logits.shape!=(2,40):raise ValueError('Branch shape')
            result['all_finite']=True
        del images,tokens,image,scales,logits,text
        result.update(implementation_hash=implementation_hash(),config_hash=config_hash(args.config),
                      status='passed',OOM=False,temporary_weight_removed=True,optimizer_steps=1,
                      micro_batch_size=config['memory']['micro_batch_size'],accumulation_steps=config['memory']['accumulation_steps'],
                      effective_batch_size=32,sdm_matrix_shape=[32,32])
        model=optimizer=scheduler=groups=loader=gallery=queries=None;gc.collect();torch.cuda.empty_cache()
        result['cuda_allocated_after_cleanup_bytes']=torch.cuda.memory_allocated()
    except Exception as error:
        result.update(status='failed',error=str(error));raise
    finally:
        if monitor is not None:result['nvml_monitor']=monitor.stop()
        write_json(args.report_dir/'gpu_preflight.json',result)
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
