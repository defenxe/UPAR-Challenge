"""Codabench-compatible sequential ensemble API; packaging/upload are separate."""
import os
from pathlib import Path
from upar.ensemble import EnsembleRetrievalEngine

HERE=Path(__file__).resolve().parent
_ENGINE=None

def load_model():
    global _ENGINE
    _ENGINE=EnsembleRetrievalEngine(
        checkpoints={fold:Path(os.environ.get('UPAR_'+fold.upper()+'_CKPT',str(HERE/'assets'/fold/'best.pth')))
                     for fold in ('market','peta','pa100k')},
        device=os.environ.get('UPAR_DEVICE','auto'),
        batch_size=int(os.environ.get('UPAR_BATCH_SIZE','128')),
        bpe_path=HERE/'data/bpe_simple_vocab_16e6.txt.gz')

def rank_gallery(sample):
    global _ENGINE
    if _ENGINE is None: load_model()
    return _ENGINE.rank_gallery(sample)
