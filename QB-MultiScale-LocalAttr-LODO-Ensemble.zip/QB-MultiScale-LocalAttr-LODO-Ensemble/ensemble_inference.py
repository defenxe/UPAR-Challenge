"""Three sequential Best models on the SAME query/gallery, with optional evaluation."""
import argparse
import json
from pathlib import Path
import numpy as np
from upar.attributes import ATTRIBUTE_NAMES
from upar.data import UPARSplit
from upar.lodo_data import DOMAINS, validation_subset
from upar.ensemble import EnsembleRetrievalEngine, canonical_sample, evaluate_score_matrix
from upar.local_scoring import stable_rank
from upar.training_common import write_json


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for fold in ('market','peta','pa100k'): parser.add_argument('--'+fold+'-ckpt',required=True)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--sample-json',help='Official-style query/gallery manifest, with optional gallery_attributes for evaluation')
    group.add_argument('--data-root',help='Build common evaluation sample from official task2/val')
    parser.add_argument('--eval-domain',choices=('all','market','peta','pa100k'),default='all')
    parser.add_argument('--output-dir',required=True,help='Fresh output directory')
    parser.add_argument('--device',default='auto')
    parser.add_argument('--batch-size',type=int,default=128)
    parser.add_argument('--query-chunk',type=int,default=32)
    parser.add_argument('--evaluate',action='store_true',help='Compute metrics on this common labeled evaluation split')
    args=parser.parse_args()
    if args.sample_json:
        manifest=Path(args.sample_json).resolve(); sample=json.loads(manifest.read_text())
        for image in sample['gallery']:
            path=Path(image['image_path'])
            if not path.is_absolute(): image['image_path']=str((manifest.parent/path).resolve())
    else:
        val=UPARSplit.read(args.data_root,'val')
        original=val
        if args.eval_domain!='all': val=validation_subset(val,DOMAINS[args.eval_domain])
        query_lookup={q:i for i,q in enumerate(original.queries)}
        sample={'attribute_names':list(ATTRIBUTE_NAMES),'queries':list(val.queries),
                'query_ids':[query_lookup[q] for q in val.queries],
                'gallery':[{'index':i,'image':r.relative_path,'image_path':str(r.image_path)} for i,r in enumerate(val.images)],
                'gallery_attributes':[list(r.attributes) for r in val.images],
                'evaluation_name':'official task2/val domain='+args.eval_domain}
    sample=canonical_sample(sample)
    if args.evaluate and 'gallery_attributes' not in sample:
        parser.error('--evaluate requires gallery_attributes in sample manifest or --data-root')
    engine=EnsembleRetrievalEngine({f:getattr(args,f+'_ckpt') for f in ('market','peta','pa100k')},
                                   device=args.device,batch_size=args.batch_size,query_chunk=args.query_chunk)
    result=engine.rank_gallery(sample,output_dir=args.output_dir)
    scores=result['similarities']; output=Path(args.output_dir)
    if scores.size:
        ranks=np.lib.format.open_memmap(str(output/'ensemble_ranking.npy'),mode='w+',dtype=np.int64,shape=scores.shape)
        for start in range(0,len(scores),args.query_chunk): ranks[start:start+args.query_chunk]=stable_rank(scores[start:start+args.query_chunk])
        ranks.flush()
    else: np.save(str(output/'ensemble_ranking.npy'),np.empty(scores.shape,dtype=np.int64))
    summary={'report_type':'ENSEMBLE_ON_COMMON_SPLIT_NOT_LODO_MACRO','output_dir':str(output.resolve()),
             'evaluation_name':sample.get('evaluation_name','caller-provided common sample'),
             'shape':list(scores.shape),'metric_scale':'fractions [0,1]',
             'unseen_caveat':'Three models together have training exposure to all three domains'}
    if args.evaluate:
        summary['metrics']=evaluate_score_matrix(scores,sample['queries'],sample['gallery_attributes'])
        write_json(output/'ensemble_metrics.json',summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
