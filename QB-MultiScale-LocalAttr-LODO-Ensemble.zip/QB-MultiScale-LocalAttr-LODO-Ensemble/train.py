from upar.lodo_training import main
if __name__ == '__main__':
    main()
