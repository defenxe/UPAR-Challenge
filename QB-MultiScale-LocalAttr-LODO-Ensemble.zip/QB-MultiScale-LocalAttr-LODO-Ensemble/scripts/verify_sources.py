"""Check protected source and copied architecture/config/protocol without mutation."""
import ast
import hashlib
import importlib
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
SOURCE=ROOT.parent/'IRRA-QB-MultiScaleLocalAttr-FullTrain'

if __name__=='__main__':
    manifest=json.loads((ROOT/'reports/source_manifest.json').read_text())
    changed=[name for name,h in manifest.items() if hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()!=h]
    if changed: raise AssertionError('Protected source changed: '+str(changed))
    preserved=[]
    for folder in ['model','solver']:
        for p in (ROOT/folder).glob('*.py'):
            if p.read_bytes()!=(SOURCE/p.relative_to(ROOT)).read_bytes(): raise AssertionError(str(p))
            preserved.append(str(p.relative_to(ROOT)))
    for name in ['config.py','model.py','multiscale_model.py','local_model.py','local_branch.py','data.py','sampling.py','masking.py','attributes.py','prompts.py','tokenizer.py','images.py','metrics.py','local_scoring.py','local_validation.py']:
        p=ROOT/'upar'/name
        if p.read_bytes()!=(SOURCE/'upar'/name).read_bytes(): raise AssertionError(str(p))
        preserved.append(str(p.relative_to(ROOT)))
    python_files=[p for p in ROOT.rglob('*.py') if '__pycache__' not in p.parts]
    for p in python_files: ast.parse(p.read_text(),filename=str(p))
    for p in (ROOT/'upar').glob('*.py'): importlib.import_module('upar.'+p.stem)
    for module in ['train','ensemble_inference','summarize_lodo','run']:importlib.import_module(module)
    actual=json.loads((SOURCE/'experiments/full60_20261011_211008_KST/config.json').read_text())
    config=json.loads((ROOT/'configs/fulltrain_lodo.json').read_text())
    assert all(config[k]==actual[k] for k in ['train','model','precision','local_lr'])
    assert (ROOT/'metadata.yaml').read_bytes()==(ROOT.parent/'examples/task2/sample_code_submission/metadata.yaml').read_bytes()
    value={'passed':True,'syntax_files':len(python_files),'all_runtime_imports':'PASS',
           'source_protected_files':len(manifest),'source_changed_files':changed,
           'byte_identical_model_loss_and_protocol_files':preserved,
           'actual_FullTrain_config_equal':True,'single_gpu_no_DDP':True,
           'submission_metadata_unchanged_from_example':True}
    (ROOT/'reports/static_checks.json').write_text(json.dumps(value,indent=2));print(json.dumps(value,indent=2))
