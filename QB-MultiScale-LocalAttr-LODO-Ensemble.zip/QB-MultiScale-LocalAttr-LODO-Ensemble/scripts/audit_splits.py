"""Read-only LODO split audit; no image decoding, training or CUDA initialization."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from upar.data import UPARSplit
from upar.lodo_data import fold_splits,audit_fold
from upar.training_common import write_json

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-root',default=str(Path(__file__).resolve().parents[2]/'data'))
    p.add_argument('--output',required=True,help='New audit JSON file')
    args=p.parse_args(); output=Path(args.output)
    if output.exists(): raise FileExistsError(output)
    public=(UPARSplit.read(args.data_root,'train'),UPARSplit.read(args.data_root,'val'))
    result={}
    for fold in ('market','peta','pa100k'):
        train,val=fold_splits(args.data_root,fold,public)
        result[fold]=audit_fold(fold,train,val,*public)
        print(fold,{k:result[fold][k] for k in ['train_images','excluded_heldout_train_images','validation_images','validation_queries']})
    write_json(output,result)
