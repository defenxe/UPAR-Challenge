"""Held-out Fusion mADM selection and domain macro means, distinct from ensemble."""
import json
import math
from pathlib import Path
import os
import torch
from .local_validation import METRICS
from .multiscale_model import save_multiscale_checkpoint
from .training_common import write_json, digest

FOLDS = ('market', 'peta', 'pa100k')
METHODS = ('Global-only', 'Global+NLL')
FOLD_NAMES = {'market':'LODO-Market', 'peta':'LODO-PETA', 'pa100k':'LODO-PA100K'}


def checked_metrics(metrics):
    if set(metrics) != set(METRICS):
        raise ValueError('Six official retrieval metrics required')
    if any(not math.isfinite(float(metrics[k])) or not 0 <= float(metrics[k]) <= 1 for k in METRICS):
        raise ValueError('Metrics must be finite fractions in [0,1]')
    return {k:float(metrics[k]) for k in METRICS}


def validate_record(record):
    if record['heldout_domain'] not in FOLDS or int(record['epoch']) < 1:
        raise ValueError('Invalid fold/epoch')
    for method in METHODS:
        checked_metrics(record['validation']['methods'][method])
    weight = float(record['validation']['best_weights']['nll'])
    if not math.isfinite(weight) or not 0 <= weight <= 1:
        raise ValueError('Invalid NLL fusion weight')


def best_record(records):
    for r in records:
        validate_record(r)
    ordered = sorted(records, key=lambda r: r['epoch'])
    return max(ordered, key=lambda r:r['validation']['methods']['Global+NLL']['mADM']) if ordered else None


def save_epoch_and_select_best(output, model, record, split_audit, train_config):
    """Epoch files are immutable; relative best symlink changes only on strict gain."""
    from dataclasses import asdict
    output = Path(output)
    validate_record(record)
    epoch, fold = int(record['epoch']), record['heldout_domain']
    if split_audit['heldout_domain'] != fold:
        raise ValueError('Record / split domain mismatch')
    weights = record['validation']['best_weights']['nll']
    metrics = checked_metrics(record['validation']['methods']['Global+NLL'])
    model.config.fusion_weight = weights
    model.config.attribute_score = 'nll'
    path = output / ('epoch_%03d.pth' % epoch)
    if path.exists():
        raise FileExistsError('Epoch checkpoint must not be overwritten')
    save_multiscale_checkpoint(path, model, epoch=epoch, epoch_complete=True,
                              heldout_domain=fold, selected_fusion_weight=weights,
                              selected_method='Global+NLL', selected_metrics=metrics,
                              lodo_selection='heldout-domain Global+NLL mean mADM')
    sha = digest(path)
    metadata = {'format_version':1, 'heldout_domain':fold, 'epoch':epoch,
                'selection_method':'heldout-domain Global+NLL mADM, strictly greater; ties earliest epoch',
                'validation_split':split_audit['validation_split'],
                'validation_images':split_audit['validation_images'],
                'validation_queries':split_audit['validation_queries'],
                'metrics':metrics, 'global_only_metrics':checked_metrics(record['validation']['methods']['Global-only']),
                'fusion_weight':weights,
                'fusion_selection':'heldout validation mean mADM; coarse .1 then +/- .1 fine .02; ties smaller weight',
                'model_config':asdict(model.config), 'train_config':train_config,
                'checkpoint_file':path.name, 'checkpoint_sha256':sha,
                'train_fingerprint':split_audit['sampling']['train_fingerprint'],
                'attribute_names':split_audit['attribute_names'],
                'selection_caveat':split_audit['selection_caveat']}
    write_json(path.with_suffix('.json'), metadata)
    best_path = output / 'best.json'
    previous = json.loads(best_path.read_text()) if best_path.exists() else None
    if previous and (previous['heldout_domain'] != fold or previous['epoch'] >= epoch):
        raise ValueError('Best metadata belongs to a different fold or a later/equal epoch')
    improved = previous is None or metrics['mADM'] > previous['metrics']['mADM']
    if improved:
        link = output / '.best.pth.tmp'
        if link.exists() or link.is_symlink():
            raise FileExistsError(link)
        link.symlink_to(path.name)
        link.replace(output / 'best.pth')
        if (output / 'best.pth').resolve() != path.resolve():
            raise AssertionError('Best weights do not point to selected epoch')
        best_metadata = dict(metadata, is_best_checkpoint=True, best_epoch=epoch, best_mADM=metrics['mADM'])
        write_json(best_path, best_metadata)
    record.update(checkpoint=path.name, checkpoint_sha256=sha, best_updated=improved,
                  best_epoch=metadata['epoch'] if improved else previous['epoch'])
    return record, best_metadata if improved else previous


def aggregate_histories(histories):
    if set(histories) != set(FOLDS):
        raise ValueError('All three named LODO histories are required')
    indexes = {}
    for fold in FOLDS:
        indexes[fold] = {}
        for record in histories[fold]:
            validate_record(record)
            if record['heldout_domain'] != fold or record['epoch'] in indexes[fold]:
                raise ValueError('Wrong fold or duplicate epoch record')
            indexes[fold][record['epoch']] = record
    common = set.intersection(*(set(indexes[f]) for f in FOLDS))
    epoch_rows = []
    for epoch in sorted(common):
        methods = {method:{metric:sum(indexes[f][epoch]['validation']['methods'][method][metric]
                                    for f in FOLDS)/3 for metric in METRICS} for method in METHODS}
        epoch_rows.append({'epoch':epoch, 'methods':methods,
                           'aggregation':'unweighted arithmetic domain macro; same epoch',
                           'domains':{f:indexes[f][epoch]['validation']['methods'] for f in FOLDS}})
    best = {fold:best_record(histories[fold]) for fold in FOLDS}
    independent = None
    if all(best.values()):
        independent = {'best_epochs':{f:best[f]['epoch'] for f in FOLDS},
                       'methods':{method:{metric:sum(best[f]['validation']['methods'][method][metric]
                                                    for f in FOLDS)/3 for metric in METRICS} for method in METHODS},
                       'aggregation':'independent Fusion-best epochs, not a single common epoch',
                       'best_epoch_selection':'Global+NLL mADM; Global-only is measured at that same Fusion-best epoch',
                       'per_domain':{f:{'epoch':best[f]['epoch'],
                                          'methods':best[f]['validation']['methods'],
                                          'fusion_weight':best[f]['validation']['best_weights']['nll']}
                                     for f in FOLDS}}
    return {'report_type':'LODO_MACRO_NOT_ENSEMBLE', 'metric_scale':'fractions [0,1]',
            'same_epoch_macro':epoch_rows, 'independent_best_macro':independent,
            'common_epochs':sorted(common),
            'available_epochs':{f:sorted(indexes[f]) for f in FOLDS},
            'missing_best_domains':[f for f in FOLDS if not best[f]],
            'weighted_by_samples':False,
            'selection_caveat':'Held-out val chooses fusion/epoch; not untouched unseen-domain test'}
