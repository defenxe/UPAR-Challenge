"""Strict source-domain LODO using only the organizer's public train/val rows."""
from collections import Counter
import csv
from dataclasses import replace
import json
import math
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from .attributes import ATTRIBUTE_NAMES
from .data import UPARSplit, TrainingDataset, validation_loaders
from .sampling import QueryBalancedSampler

DOMAINS = {'market': 'Market1501', 'pa100k': 'PA100k', 'peta': 'PETA'}

def domain(record):
    prefix = record.relative_path.split('/')[0]
    if prefix not in DOMAINS.values():
        raise ValueError('Unknown source domain: ' + prefix)
    return prefix


def training_subset(public_train, heldout):
    """Rebuild IDs and query vocabulary after removing every held-out row."""
    selected = tuple(r for r in public_train.images if domain(r) != heldout)
    queries, mapping, images = [], {}, []
    for record in selected:
        if record.attributes not in mapping:
            mapping[record.attributes] = len(queries)
            queries.append(record.attributes)
        images.append(replace(record, query_index=mapping[record.attributes]))
    if not images:
        raise ValueError('Empty fold train')
    return UPARSplit('train', tuple(images), tuple(queries))


def validation_subset(public_val, heldout):
    selected = tuple(r for r in public_val.images if domain(r) == heldout)
    represented = {r.attributes for r in selected}
    # Preserve organizer query order, retaining only queries with an exact match.
    queries = tuple(q for q in public_val.queries if q in represented)
    mapping = {q: i for i, q in enumerate(queries)}
    if not selected or not queries or represented != set(queries):
        raise ValueError('Invalid held-out gallery/query partition')
    return UPARSplit('val', tuple(replace(r, query_index=mapping[r.attributes])
                                  for r in selected), queries)


def fold_splits(data_root, fold, public=None):
    heldout = DOMAINS[fold]
    train, val = public or (UPARSplit.read(data_root, 'train'), UPARSplit.read(data_root, 'val'))
    return training_subset(train, heldout), validation_subset(val, heldout)


def fold_loaders(train, val, tokenizer, config):
    loader = DataLoader(TrainingDataset(train, tokenizer), batch_size=config.batch_size,
                        sampler=QueryBalancedSampler(train, config.seed),
                        num_workers=config.num_workers,
                        generator=torch.Generator().manual_seed(config.seed))
    gallery, queries = validation_loaders(val, tokenizer, config.test_batch_size,
                                         config.num_workers)
    return loader, gallery, queries



def audit_fold(fold, train, val, public_train, public_val, seed=1):
    """Audit annotations only; train loader/sampler never receive held-out rows."""
    from collections import Counter
    import hashlib
    heldout = DOMAINS[fold]
    train_paths = {r.image_path for r in train.images}
    val_paths = {r.image_path for r in val.images}
    all_heldout = {r.image_path for s in (public_train, public_val) for r in s.images if domain(r) == heldout}
    if train_paths & all_heldout or train_paths & val_paths:
        raise ValueError('Held-out/validation images leaked into training')
    if {r.image_path for r in public_train.images} & {r.image_path for r in public_val.images}:
        raise ValueError('Public train/val image overlap')
    expected = {r.relative_path for r in public_train.images if domain(r) != heldout}
    if {r.relative_path for r in train.images} != expected:
        raise ValueError('Fold is not exactly the two allowed public training domains')
    if any(domain(r) == heldout for r in train.images) or any(domain(r) != heldout for r in val.images):
        raise ValueError('Invalid fold domains')
    for split in (train, val):
        if set(split.queries) != {r.attributes for r in split.images}:
            raise ValueError('Query vocabulary includes non-represented vectors')
        if any(split.queries[r.query_index] != r.attributes for r in split.images):
            raise ValueError('Query ID/attribute mismatch')
    sampler = QueryBalancedSampler(train, seed)
    expected_counts = Counter(r.attributes for r in train.images)
    if sampler.counts != expected_counts or sampler.num_samples != len(train.images):
        raise ValueError('Sampler statistics mismatch')
    draws = list(sampler)
    sampled_domains = Counter(domain(train.images[i]) for i in draws)
    if heldout in sampled_domains:
        raise ValueError('Sampler selected held-out domain')
    result = {'heldout_domain': fold, 'heldout_source_prefix': heldout,
              'training_domains': [k for k in DOMAINS if k != fold],
              'train_domain_images': dict(Counter(domain(r) for r in train.images)),
              'public_train_domain_images': dict(Counter(domain(r) for r in public_train.images)),
              'train_images': len(train.images), 'train_queries': len(train.queries),
              'excluded_heldout_train_images': sum(domain(r) == heldout for r in public_train.images),
              'validation_images': len(val.images), 'validation_queries': len(val.queries),
              'removed_validation_queries_without_exact_match': len(public_val.queries) - len(val.queries),
              'validation_split': 'official task2/val, domain-only gallery, official query order with exact matches',
              'validation_gallery_ids': [r.relative_path for r in val.images],
              'validation_query_ids': [public_val.queries.index(q) for q in val.queries],
              'sampling': sampler.metadata(), 'epoch1_sampled_domains': dict(sampled_domains),
              'training_image_ids_sha256': hashlib.sha256('\n'.join(r.relative_path for r in train.images).encode()).hexdigest(),
              'train_heldout_image_intersection': 0, 'heldout_in_sampler': 0,
              'query_vocabulary_rebuilt_from_train_only': True,
              'attribute_names': list(ATTRIBUTE_NAMES), 'checks_passed': True,
              'selection_caveat': 'Held-out val chooses fusion and epoch; not untouched unseen-domain test'}
    return result
