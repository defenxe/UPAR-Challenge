"""AMP API compatibility helpers for older and current PyTorch releases."""
from contextlib import nullcontext

import torch


def make_grad_scaler(enabled=True):
    """Create a CUDA GradScaler across PyTorch AMP API generations.

    PyTorch 1.12 exposes the scaler as ``torch.cuda.amp.GradScaler``. Newer
    releases expose the device-aware ``torch.amp.GradScaler`` API. Prefer the
    latter when its constructor is available, then fall back to the 1.12 API.
    """
    amp_namespace = getattr(torch, 'amp', None)
    scaler_type = getattr(amp_namespace, 'GradScaler', None)
    if scaler_type is not None:
        try:
            return scaler_type(device='cuda', enabled=enabled)
        except TypeError:
            # Some intermediate releases exposed torch.amp before adding its
            # device argument; use the stable CUDA namespace in that case.
            pass
    return torch.cuda.amp.GradScaler(enabled=enabled)


def autocast_context(device_type='cuda', enabled=True):
    """Return an autocast context supported by the installed PyTorch.

    CPU training here uses full precision. Avoid asking older PyTorch builds
    to initialize their CUDA autocast machinery for a disabled CPU context.
    """
    if device_type != 'cuda' and not enabled:
        return nullcontext()

    autocast = getattr(torch, 'autocast', None)
    if autocast is not None:
        return autocast(device_type=device_type, enabled=enabled)
    if device_type == 'cuda':
        return torch.cuda.amp.autocast(enabled=enabled)
    return nullcontext()
