"""IRRA encoder and cross-modal prediction components for SDM + MAP only."""
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace

import torch

from model.build import IRRA
from model.clip_model import CLIP, build_CLIP_from_openai_pretrained
from model.objectives import compute_attribute_sdm, compute_map

from .config import ModelConfig
from .masking import IGNORE_INDEX


def check_clip_config(config):
    expected = {
        'embed_dim': 512, 'vision_layers': 12, 'vision_width': 768,
        'vision_patch_size': 16, 'context_length': 77, 'vocab_size': 49408,
        'transformer_width': 512, 'transformer_heads': 8, 'transformer_layers': 12,
        'stride_size': 16,
    }
    if any(config.get(key) != value for key, value in expected.items()):
        raise ValueError('UPAR requires the DESIGN.md CLIP ViT-B/16 backbone')
    if tuple(config.get('image_resolution', ())) != (384, 128):
        raise ValueError('UPAR image resolution must be (height=384, width=128)')


class UPARModel(IRRA):
    def __init__(self, clip_model, clip_config, config=None, with_map=True):
        self.config = config or ModelConfig()
        check_clip_config(clip_config)
        if (tuple(self.config.img_size) != (384, 128) or self.config.stride_size != 16
                or self.config.text_length != 77 or self.config.vocab_size != 49408
                or self.config.cmt_depth != 4):
            raise ValueError('Model geometry must follow DESIGN.md')
        args = SimpleNamespace(**asdict(self.config),
                               loss_names='sdm+map' if with_map else 'sdm')
        # Inherit IRRA's exact cross-attention, four transformer blocks and head.
        # No classifier is constructed: neither configuration contains ID loss.
        super().__init__(args, num_classes=0, base_model=clip_model, base_cfg=clip_config)
        self.clip_config = dict(clip_config)
        self.with_map = with_map
        # A fixed temperature travels with the checkpoint and the model device.
        del self.logit_scale
        self.register_buffer('logit_scale', torch.tensor(1.0 / self.config.temperature))

    @classmethod
    def from_local_pretrained(cls, checkpoint_path, config=None):
        path = Path(checkpoint_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(f'Provide a local OpenAI CLIP ViT-B/16 checkpoint: {path}')
        clip, clip_config = build_CLIP_from_openai_pretrained(
            str(path), (384, 128), 16, strict_load=True)
        return cls(clip, clip_config, config=config, with_map=True).float()

    @classmethod
    def from_checkpoint_dict(cls, checkpoint, with_map=False):
        from .checkpoint import check_checkpoint
        check_checkpoint(checkpoint)
        config = ModelConfig(**checkpoint['model_config'])
        clip_config = dict(checkpoint['clip_config'])
        clip_config['image_resolution'] = tuple(clip_config['image_resolution'])
        model = cls(CLIP(**clip_config), clip_config, config, with_map=with_map)
        state = checkpoint['model']
        if not with_map:
            state = {key: value for key, value in state.items()
                     if key.startswith('base_model.') or key == 'logit_scale'}
        model.load_state_dict(state, strict=True)
        return model.float()

    def encode_text(self, token_ids):
        # Explicit EOS lookup also works if masked tokens are present in a sequence.
        eos = token_ids.eq(49407)
        if not torch.all(eos.sum(dim=1).eq(1)):
            raise ValueError('Every prompt must contain exactly one CLIP EOS token')
        features = self.base_model.encode_text(token_ids)
        indices = eos.long().argmax(dim=1)
        return features[torch.arange(len(token_ids), device=token_ids.device), indices].float()

    def forward(self, batch):
        if not self.training or not self.with_map:
            raise RuntimeError('UPAR forward is for SDM+MAP training; use encode_image/text for inference')
        images, token_ids = batch['images'], batch['caption_ids']
        image_tokens, text_tokens = self.base_model(images, token_ids)
        image_global = image_tokens[:, 0, :].float()
        eos_positions = token_ids.eq(49407).long().argmax(dim=1)
        text_global = text_tokens[
            torch.arange(len(token_ids), device=token_ids.device), eos_positions].float()
        sdm_loss = compute_attribute_sdm(
            image_global, text_global, batch['attributes'], self.logit_scale)
        masked_tokens = self.base_model.encode_text(batch['map_ids'])
        fused = self.cross_former(masked_tokens, image_tokens, image_tokens)
        selected = batch['map_labels'].ne(IGNORE_INDEX)
        # The inherited vocabulary head is evaluated only at supervised positions.
        scores = self.mlm_head(fused[selected]).float()
        labels = batch['map_labels'][selected]
        map_loss = compute_map(scores, labels) * self.config.map_loss_weight
        accuracy = (scores.argmax(dim=-1).eq(labels).float().mean() if labels.numel()
                    else scores.sum() * 0.0)
        return {'sdm_loss': sdm_loss, 'map_loss': map_loss,
                'map_acc': accuracy, 'map_tokens': selected.sum(),
                'temperature': self.logit_scale.reciprocal()}
