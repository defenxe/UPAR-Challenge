"""Offline checkpoint schema shared by training, resume, export and submission."""
from dataclasses import asdict
from pathlib import Path

import torch

from .attributes import ATTRIBUTE_NAMES, check_attribute_names
from .prompts import PROMPT_VERSION

FORMAT_VERSION = 1


def check_checkpoint(checkpoint):
    if checkpoint.get('format_version') != FORMAT_VERSION:
        raise ValueError('Unsupported UPAR checkpoint format')
    if checkpoint.get('prompt_version') != PROMPT_VERSION:
        raise ValueError('Checkpoint prompt rule differs from the inference prompt rule')
    check_attribute_names(checkpoint.get('attribute_names', ()))
    for key in ('model', 'model_config', 'clip_config'):
        if key not in checkpoint:
            raise ValueError(f'Missing checkpoint field: {key}')
    if any('classifier' in key for key in checkpoint['model']):
        raise ValueError('PID/classification checkpoints cannot be used for UPAR')


def load_checkpoint(path):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f'Local trained UPAR checkpoint is required: {path}')
    try:
        checkpoint = torch.load(path, map_location='cpu', weights_only=True)
    except TypeError as error:
        # PyTorch 1.12 does not expose weights_only; keep its local checkpoint
        # loading path available while preferring the restricted loader later.
        if 'weights_only' not in str(error):
            raise
        checkpoint = torch.load(path, map_location='cpu')
    check_checkpoint(checkpoint)
    return checkpoint


def checkpoint_dict(model):
    return {
        'format_version': FORMAT_VERSION,
        'attribute_names': list(ATTRIBUTE_NAMES),
        'prompt_version': PROMPT_VERSION,
        'model_config': asdict(model.config),
        'clip_config': model.clip_config,
        'model': model.state_dict(),
    }


def save_checkpoint(path, model, **training_state):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    checkpoint = checkpoint_dict(model)
    checkpoint.update(training_state)
    temporary = path.with_suffix(path.suffix + '.tmp')
    torch.save(checkpoint, temporary)
    temporary.replace(path)


def save_inference_checkpoint(path, model, epoch):
    checkpoint = checkpoint_dict(model)
    checkpoint['model'] = {key: value for key, value in checkpoint['model'].items()
                           if key.startswith('base_model.') or key == 'logit_scale'}
    checkpoint['epoch'] = epoch
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    torch.save(checkpoint, temporary)
    temporary.replace(path)
