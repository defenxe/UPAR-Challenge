"""Only the local branch changes: weighted patch features from blocks 4/8/12."""
from dataclasses import dataclass
import torch
from torch import nn
import torch.nn.functional as F
from model.clip_model import CLIP
from model.objectives import compute_attribute_sdm, compute_map
from .checkpoint import check_checkpoint, checkpoint_dict
from .local_model import GlobalLocalModel, LocalModelConfig
from .masking import IGNORE_INDEX

ARCHITECTURE = 'qb-multiscale-local-4-8-12-weighted-v1'


@dataclass
class MultiScaleModelConfig(LocalModelConfig):
    multiscale_blocks: tuple = (4, 8, 12)
    initial_scale_weights: tuple = (0.2, 0.2, 0.6)


class WeightedPatchFusion(nn.Module):
    def __init__(self, weights):
        super().__init__()
        self.norms = nn.ModuleDict({str(b): nn.LayerNorm(768) for b in (4, 8)})
        self.projections = nn.ModuleDict({str(b): nn.Linear(768, 512) for b in (4, 8)})
        self.fusion_logits = nn.Parameter(torch.tensor(weights).float().log())

    def aligned(self, intermediate, final):
        if set(intermediate) != {4, 8} or final.shape[1:] != (193, 512):
            raise ValueError('Require blocks 4/8 and final projected CLIP tokens')
        features = []
        for block in (4, 8):
            raw = intermediate[block]
            if raw.shape != (len(final), 192, 768):
                raise ValueError('Intermediate features must exclude CLS: [B,192,768]')
            features.append(self.projections[str(block)](self.norms[str(block)](raw)))
        # Block 12 already passed through CLIP ln_post and 768->512 projection.
        features.append(final[:, 1:])
        return features

    def forward(self, intermediate, final):
        features = self.aligned(intermediate, final)
        weights = self.fusion_logits.softmax(0)
        # No [B,3,192,512] stack or extra encoder passes.
        return sum(weights[k] * feature for k, feature in enumerate(features))


class MultiScaleLocalModel(GlobalLocalModel):
    def __init__(self, clip_model, clip_config, config=None, with_map=True):
        config = config or MultiScaleModelConfig()
        if tuple(config.multiscale_blocks) != (4, 8, 12):
            raise ValueError('This experiment fixes blocks 4/8/12 (indices 3/7/11)')
        weights = torch.tensor(config.initial_scale_weights)
        if not torch.isfinite(weights).all() or not (weights > 0).all() or abs(float(weights.sum()) - 1) > 1e-6:
            raise ValueError('Initial fusion weights must be positive and sum to one')
        super().__init__(clip_model, clip_config, config, with_map)
        # Preserve fresh QB MAP and parent RNG initialization exactly.
        with torch.random.fork_rng(devices=[]):
            self.multiscale = WeightedPatchFusion(config.initial_scale_weights)

    def image_tokens_and_scales(self, images):
        return self.base_model.visual(images.type(self.base_model.dtype), return_intermediate=True)

    def local_from_tokens(self, image_tokens, intermediate):
        return self.local_branch(self.multiscale(intermediate, image_tokens))[0]

    def encode_image_and_attributes(self, images):
        tokens, intermediate = self.image_tokens_and_scales(images)
        return tokens[:, 0].float(), self.local_from_tokens(tokens, intermediate)

    def forward(self, batch):
        if not self.training or not self.with_map:
            raise RuntimeError('Training requires train mode and MAP modules')
        image_tokens, intermediate = self.image_tokens_and_scales(batch['images'])
        token_ids = batch['caption_ids']
        text_tokens = self.base_model.encode_text(token_ids)
        eos = token_ids.eq(49407).long().argmax(1)
        text_global = text_tokens[torch.arange(len(token_ids), device=token_ids.device), eos].float()
        sdm = compute_attribute_sdm(image_tokens[:, 0].float(), text_global,
                                    batch['attributes'], self.logit_scale)
        masked = self.base_model.encode_text(batch['map_ids'])
        fused = self.cross_former(masked, image_tokens, image_tokens)
        selected = batch['map_labels'].ne(IGNORE_INDEX)
        scores = self.mlm_head(fused[selected]).float()
        labels = batch['map_labels'][selected]
        map_loss = compute_map(scores, labels) * self.config.map_loss_weight
        accuracy = scores.argmax(-1).eq(labels).float().mean() if labels.numel() else scores.sum() * 0
        logits = self.local_from_tokens(image_tokens, intermediate)
        attributes = batch['attributes']
        if attributes.shape != logits.shape or not ((attributes == 0) | (attributes == 1)).all():
            raise ValueError('Attribute BCE labels must be binary [B,40] in official order')
        bce = F.binary_cross_entropy_with_logits(logits.float(), attributes.float())
        return {'sdm_loss': sdm, 'map_loss': map_loss, 'attr_bce': bce,
                'attr_loss': self.config.attr_loss_weight * bce, 'attribute_logits': logits,
                'map_acc': accuracy, 'map_tokens': selected.sum(),
                'temperature': self.logit_scale.reciprocal()}

    @classmethod
    def from_checkpoint_dict(cls, checkpoint, with_map=False):
        check_checkpoint(checkpoint)
        if checkpoint.get('architecture') != ARCHITECTURE:
            raise ValueError('Not a MultiScale 4/8/12 checkpoint')
        config = MultiScaleModelConfig(**checkpoint['model_config'])
        clip_config = dict(checkpoint['clip_config'])
        clip_config['image_resolution'] = tuple(clip_config['image_resolution'])
        model = cls(CLIP(**clip_config), clip_config, config, with_map)
        state = checkpoint['model']
        if not with_map:
            state = {k: v for k, v in state.items()
                     if k.startswith(('base_model.', 'local_branch.', 'multiscale.')) or k == 'logit_scale'}
        model.load_state_dict(state, strict=True)
        return model.float()


def save_multiscale_checkpoint(path, model, **training_state):
    from pathlib import Path
    path = Path(path)
    value = checkpoint_dict(model)
    value.update(training_state)
    value['architecture'] = ARCHITECTURE
    if 'selected_fusion_weight' in training_state:
        value['model_config']['fusion_weight'] = training_state['selected_fusion_weight']
        value['fusion_weight'] = training_state['selected_fusion_weight']
    value['multiscale_weights'] = model.multiscale.fusion_logits.detach().softmax(0).cpu().tolist()
    temporary = path.with_suffix(path.suffix + '.tmp')
    torch.save(value, temporary)
    temporary.replace(path)
