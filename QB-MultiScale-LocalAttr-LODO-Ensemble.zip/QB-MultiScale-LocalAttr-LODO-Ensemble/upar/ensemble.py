"""Sequential best-checkpoint Global+NLL score average on one common gallery."""
import gc
import hashlib
import json
from pathlib import Path
import tempfile
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from .attributes import ATTRIBUTE_NAMES
from .images import image_transform, read_rgb
from .local_model import load_artifact
from .local_scoring import attribute_scores, fuse, stable_rank
from .multiscale_model import MultiScaleLocalModel, ARCHITECTURE
from .prompts import encode_query
from .tokenizer import PromptTokenizer
from .training_common import digest, write_json
from .lodo_results import FOLDS, checked_metrics
from .local_validation import METRICS
from .metrics import metrics_for_ranking


def canonical_sample(sample):
    names=list(sample['attribute_names'])
    if len(names)!=40 or len(set(names))!=40 or set(names)!=set(ATTRIBUTE_NAMES):
        raise ValueError('Exactly the canonical 40 named attributes required')
    matrix=np.asarray(sample['queries'])
    if len(sample['queries'])==0: matrix=np.empty((0,40),dtype=np.int64)
    if matrix.ndim!=2 or matrix.shape[1]!=40 or not np.isin(matrix,(0,1)).all():
        raise ValueError('Binary [Q,40] queries required')
    order=[names.index(name) for name in ATTRIBUTE_NAMES]
    result=dict(sample,attribute_names=list(ATTRIBUTE_NAMES),queries=matrix[:,order].tolist())
    if 'gallery_attributes' in sample:
        labels=np.asarray(sample['gallery_attributes'])
        if labels.shape!=(len(sample['gallery']),40) or not np.isin(labels,(0,1)).all():
            raise ValueError('Gallery evaluation labels must be binary [G,40]')
        result['gallery_attributes']=labels[:,order].tolist()
    return result


def sample_ids(sample):
    query_ids=[str(x) for x in sample.get('query_ids',range(len(sample['queries'])))]
    gallery_ids=[]
    for item in sample['gallery']:
        identity=item.get('image',item.get('image_id',item.get('image_path')))
        if identity is None: raise ValueError('Gallery requires image identity/path')
        gallery_ids.append(str(identity))
    if len(query_ids)!=len(sample['queries']) or len(set(query_ids))!=len(query_ids) or len(set(gallery_ids))!=len(gallery_ids):
        raise ValueError('Query/gallery IDs must be unique and match row counts')
    return query_ids,gallery_ids


def tensor_state_digest(state):
    """Hash only retrieval weights, so different epoch metadata cannot fake 3 models."""
    h=hashlib.sha256()
    keys=sorted(k for k in state if k.startswith(('base_model.','local_branch.','multiscale.')) or k=='logit_scale')
    if not keys: raise ValueError('No retrieval state tensors')
    for key in keys:
        value=state[key].detach().cpu().contiguous()
        h.update((key+str(value.dtype)+str(tuple(value.shape))).encode())
        h.update(memoryview(value.numpy()))
    return h.hexdigest()


def load_best_artifact(path,fold):
    path=Path(path).resolve() if Path(path).name!='best.pth' else Path(path).absolute()
    metadata_path=path.with_suffix('.json')
    metadata=json.loads(metadata_path.read_text())
    if not metadata.get('is_best_checkpoint') or metadata.get('best_epoch')!=metadata['epoch'] or metadata.get('best_mADM')!=metadata['metrics']['mADM']:
        raise ValueError('Provide selected best.pth and its best.json, not an arbitrary Epoch checkpoint')
    if metadata['heldout_domain']!=fold or metadata['attribute_names']!=list(ATTRIBUTE_NAMES):
        raise ValueError('Best checkpoint belongs to wrong fold/attribute schema')
    if digest(path)!=metadata['checkpoint_sha256']:
        raise ValueError('Best file bytes differ from selected epoch metadata')
    artifact=load_artifact(path)
    if artifact.get('architecture')!=ARCHITECTURE or artifact.get('heldout_domain')!=fold or not artifact.get('epoch_complete'):
        raise ValueError('Not a completed LODO MultiScale checkpoint')
    if artifact['epoch']!=metadata['epoch'] or artifact['selected_method']!='Global+NLL' or artifact['model_config']['attribute_score']!='nll':
        raise ValueError('Wrong Best Epoch/method')
    weight=float(metadata['fusion_weight'])
    if not np.isfinite(weight) or not 0<=weight<=1 or artifact['model_config']['fusion_weight']!=weight or artifact['selected_fusion_weight']!=weight:
        raise ValueError('Fusion weight missing/mismatch')
    if checked_metrics(artifact['selected_metrics'])!=checked_metrics(metadata['metrics']):
        raise ValueError('Best Epoch metrics mismatch')
    if json.loads(json.dumps(artifact['model_config']))!=metadata['model_config']:
        raise ValueError('Model configuration differs from metadata')
    if any(v.is_floating_point() and v.dtype!=torch.float32 for v in artifact['model'].values()):
        raise ValueError('Expected FullTrain FP32 checkpoint')
    weight_sha=tensor_state_digest(artifact['model'])
    return artifact,metadata,weight_sha


class Gallery(Dataset):
    def __init__(self,items): self.items=items; self.transform=image_transform()
    def __len__(self): return len(self.items)
    def __getitem__(self,index): return self.transform(read_rgb(self.items[index]['image_path']))


def alignment_indices(source_ids,target_ids):
    if len(set(source_ids))!=len(source_ids) or len(set(target_ids))!=len(target_ids) or set(source_ids)!=set(target_ids):
        raise ValueError('Cannot align different/duplicate query or image IDs')
    lookup={identity:i for i,identity in enumerate(source_ids)}
    return np.asarray([lookup[identity] for identity in target_ids],dtype=np.int64)


def average_score_bundles(bundles,query_ids,gallery_ids,output,query_vectors=None,chunk_size=32):
    """Reorder scores by IDs, sum final fused scores, divide by exactly three."""
    if len(bundles)!=3 or chunk_size<=0: raise ValueError('Exactly three score bundles required')
    output=Path(output)
    shape=(len(query_ids),len(gallery_ids))
    if not all(shape):
        result=np.empty(shape,dtype=np.float64); np.save(str(output),result); return result
    result=np.lib.format.open_memmap(str(output),mode='w+',dtype=np.float64,shape=shape)
    aligned=[]
    for bundle in bundles:
        matrix=np.load(str(bundle['path']),mmap_mode='r')
        if matrix.shape!=(len(bundle['query_ids']),len(bundle['gallery_ids'])) or matrix.shape!=shape:
            raise ValueError('Score matrix shape/ID mismatch')
        rows=alignment_indices(bundle['query_ids'],query_ids)
        columns=alignment_indices(bundle['gallery_ids'],gallery_ids)
        if query_vectors is not None:
            if not np.array_equal(np.asarray(bundle['query_vectors'])[rows],np.asarray(query_vectors)):
                raise ValueError('Different queries share the same IDs')
        aligned.append((matrix,rows,columns))
    for start in range(0,len(query_ids),chunk_size):
        stop=min(start+chunk_size,len(query_ids)); summed=np.zeros((stop-start,len(gallery_ids)),dtype=np.float64)
        for matrix,rows,columns in aligned:
            values=matrix[rows[start:stop]][:,columns]
            if not np.isfinite(values).all(): raise ValueError('Nonfinite model scores')
            summed+=values
        result[start:stop]=summed/3.
        if not np.isfinite(result[start:stop]).all(): raise ValueError('Nonfinite ensemble score')
    result.flush()
    return result


def score_distribution(matrix,chunk_size=32):
    n=0; total=0.; square=0.; minimum=None; maximum=None
    for start in range(0,len(matrix),chunk_size):
        a=np.asarray(matrix[start:start+chunk_size],dtype=np.float64)
        if not np.isfinite(a).all(): raise ValueError('Nonfinite scores')
        if not a.size: continue
        n+=a.size; total+=float(a.sum()); square+=float(np.square(a).sum())
        minimum=float(a.min()) if minimum is None else min(minimum,float(a.min()))
        maximum=float(a.max()) if maximum is None else max(maximum,float(a.max()))
    return {'count':n,'mean':total/n if n else None,
            'std':float(np.sqrt(max(0.,square/n-(total/n)**2))) if n else None,'min':minimum,'max':maximum}


class EnsembleRetrievalEngine:
    def __init__(self,checkpoints,device='auto',batch_size=128,query_chunk=32,bpe_path=None,
                 model_factory=None):
        if set(checkpoints)!=set(FOLDS) or len({str(Path(p).resolve()) for p in checkpoints.values()})!=3:
            raise ValueError('Three independent fold Best checkpoint paths required')
        if batch_size<=0 or query_chunk<=0: raise ValueError('Invalid chunk size')
        self.checkpoints={f:Path(checkpoints[f]) for f in FOLDS}
        self.device=torch.device('cuda:0' if device=='auto' and torch.cuda.is_available() else 'cpu' if device=='auto' else device)
        if self.device.type=='cuda' and torch.cuda.device_count()!=1:
            raise ValueError('Expose exactly one GPU for sequential inference')
        self.batch_size,self.query_chunk=batch_size,query_chunk
        self.tokenizer=PromptTokenizer(bpe_path)
        self.model_factory=model_factory or (lambda checkpoint:MultiScaleLocalModel.from_checkpoint_dict(checkpoint,with_map=False))
        self._temporary=[]

    @torch.inference_mode()
    def _score_model(self,model,sample,path):
        q=np.asarray(sample['queries'],dtype=np.int64)
        shape=(len(q),len(sample['gallery']))
        if not all(shape):
            a=np.empty(shape,dtype=np.float64); np.save(str(path),a); return a
        text,images,logits=[],[],[]
        for start in range(0,len(q),self.batch_size):
            tokens=torch.tensor([encode_query(v,self.tokenizer).token_ids for v in q[start:start+self.batch_size]],
                                dtype=torch.long,device=self.device)
            text.append(model.encode_text(tokens).float().cpu())
        gallery_loader=DataLoader(Gallery(sample['gallery']),batch_size=self.batch_size,shuffle=False,num_workers=0)
        for index,batch in enumerate(gallery_loader,1):
            features,z=model.encode_image_and_attributes(batch.to(self.device))
            images.append(features.float().cpu()); logits.append(z.float().cpu())
            if index==1 or index%40==0 or index==len(gallery_loader):
                print('Ensemble %s gallery batches %d/%d' % (getattr(self,'_active_fold','model'),index,len(gallery_loader)),flush=True)
        text=F.normalize(torch.cat(text),dim=1)
        images=F.normalize(torch.cat(images),dim=1); logits=torch.cat(logits)
        matrix=np.lib.format.open_memmap(str(path),mode='w+',dtype=np.float64,shape=shape)
        for start in range(0,len(q),self.query_chunk):
            global_scores=(text[start:start+self.query_chunk]@images.t()).numpy()
            nll,_=attribute_scores(q[start:start+self.query_chunk],logits)
            matrix[start:start+self.query_chunk]=fuse(global_scores,nll,model.config.fusion_weight)
            if not np.isfinite(matrix[start:start+self.query_chunk]).all(): raise ValueError('Nonfinite fused scores')
        matrix.flush(); return matrix

    def rank_gallery(self,sample,output_dir=None):
        sample=canonical_sample(sample)
        qids,gids=sample_ids(sample)
        if output_dir is None:
            temp=tempfile.TemporaryDirectory(prefix='upar_lodo_ensemble_'); self._temporary.append(temp)
            output=Path(temp.name)/'scores'
        else: output=Path(output_dir)
        output.mkdir(parents=True,exist_ok=False)
        provenance={}; bundles=[]; state_hashes=set()
        for fold in FOLDS:
            self._active_fold=fold
            print('Loading LODO %s Best checkpoint' % fold,flush=True)
            artifact,metadata,state_hash=load_best_artifact(self.checkpoints[fold],fold)
            if state_hash in state_hashes: raise ValueError('Different folds contain identical retrieval weights')
            state_hashes.add(state_hash)
            model=self.model_factory(artifact).float().to(self.device).eval()
            try:
                if model.config.fusion_weight!=metadata['fusion_weight']:
                    raise ValueError('Loaded model uses wrong Fusion Weight')
                path=output/(fold+'_fused_scores.npy')
                matrix=self._score_model(model,sample,path)
                provenance[fold]={'checkpoint':str(self.checkpoints[fold].absolute()),'epoch':metadata['epoch'],
                    'checkpoint_sha256':metadata['checkpoint_sha256'],'retrieval_state_sha256':state_hash,
                    'fusion_weight':metadata['fusion_weight'],'score_distribution':score_distribution(matrix),
                    'heldout_validation_split':metadata['validation_split']}
                bundles.append({'path':path,'query_ids':qids,'gallery_ids':gids,'query_vectors':sample['queries']})
                print('LODO %s Epoch %d Fusion Weight %.4f scores saved' % (fold,metadata['epoch'],metadata['fusion_weight']),flush=True)
                del matrix
            finally:
                del model,artifact
                gc.collect()
                if self.device.type=='cuda': torch.cuda.empty_cache()
        ensemble=average_score_bundles(bundles,qids,gids,output/'ensemble_scores.npy',sample['queries'],self.query_chunk)
        write_json(output/'score_ids.json',{'query_ids':qids,'gallery_ids':gids,'query_vectors':sample['queries']})
        write_json(output/'ensemble_metadata.json',{'report_type':'ENSEMBLE_ON_COMMON_SPLIT_NOT_LODO_MACRO',
            'models':provenance,'score_shape':list(ensemble.shape),'ensemble_weights':[1/3]*3,
            'formula':'(Market fused score + PETA fused score + PA100K fused score) / 3',
            'normalization_after_model_fusion':'none','gpu_models_loaded_simultaneously':1 if self.device.type=='cuda' else 0,
            'evaluation_name':sample.get('evaluation_name','caller-provided common query/gallery'),
            'unseen_caveat':'The union of the three models training domains covers all three domains'})
        self.last_output=output
        return {'similarities':ensemble}


def evaluate_score_matrix(scores,query_attributes,gallery_attributes):
    if np.shape(scores)!=(len(query_attributes),len(gallery_attributes)) or not len(query_attributes):
        raise ValueError('Evaluation shape/nonempty query mismatch')
    totals={m:0. for m in METRICS}
    for row,query in zip(scores,query_attributes):
        values=metrics_for_ranking(stable_rank(row),query,gallery_attributes)
        for metric in METRICS: totals[metric]+=values[metric]
    return {m:v/len(query_attributes) for m,v in totals.items()}
