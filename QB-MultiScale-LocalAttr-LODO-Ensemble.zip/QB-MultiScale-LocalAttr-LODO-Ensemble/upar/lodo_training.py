"""Independent single-GPU LODO FullTrain; unchanged backbone/loss/epoch schedule."""
import argparse
import csv
from dataclasses import asdict
from datetime import datetime
import json
import os
from pathlib import Path
import socket
import time
import uuid
import torch
from solver import build_lr_scheduler
from .config import TrainConfig
from .data import UPARSplit
from .lodo_data import DOMAINS, fold_splits, fold_loaders, audit_fold
from .lodo_results import FOLD_NAMES, save_epoch_and_select_best
from .local_validation import KST, METRICS, log, evaluate_local
from .multiscale_model import MultiScaleLocalModel, MultiScaleModelConfig
from .tokenizer import PromptTokenizer
from .training_common import Tee, write_json, seed_all, optimizer_for, verify_pretrained, update

ROOT = Path(__file__).resolve().parents[1]


def read_config(path):
    config = json.loads(Path(path).read_text())
    if config['precision'] != 'FP32':
        raise ValueError('FullTrain reference uses FP32')
    return config, TrainConfig(**config['train']), MultiScaleModelConfig(**config['model'])


def method_weight(method, validation):
    if method == 'Global-only': return 0.
    if method.endswith('-only'): return 1.
    if method.endswith('fixed0.40'): return .4
    return validation['best_weights']['nll' if method == 'Global+NLL' else 'agreement']


def run(args):
    config, train_config, model_config = read_config(args.config)
    public_train, public_val = UPARSplit.read(args.data_root, 'train'), UPARSplit.read(args.data_root, 'val')
    train, heldout_val = fold_splits(args.data_root, args.heldout_domain, (public_train, public_val))
    audit = audit_fold(args.heldout_domain, train, heldout_val, public_train, public_val, train_config.seed)
    if args.dry_run:
        print(json.dumps({'config':config, 'split_audit':audit,
                          'training_started':False}, indent=2))
        return
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError('Expose exactly one GPU with CUDA_VISIBLE_DEVICES; no DDP is used')
    pretrained = Path(args.pretrained).resolve()
    if not pretrained.is_file(): raise FileNotFoundError(pretrained)
    output = Path(args.output).resolve() if args.output else ROOT / 'experiments' / FOLD_NAMES[args.heldout_domain] / (
        datetime.now(KST).strftime('%Y%m%d_%H%M%S_KST_') + uuid.uuid4().hex[:8])
    # Never write into the original reference project, even if --output is misconfigured.
    reference = ROOT.parent / 'IRRA-QB-MultiScaleLocalAttr-FullTrain'
    if output == reference or reference in output.parents:
        raise ValueError('Cannot write to the protected FullTrain reference')
    output.mkdir(parents=True, exist_ok=False)
    import sys
    sys.stdout = Tee(sys.stdout, output / 'train.log')
    write_json(output / 'split_audit.json', audit)
    log('LODO split ' + json.dumps({k:v for k,v in audit.items() if k not in ('validation_gallery_ids','validation_query_ids','attribute_names')}))
    # Retain no public held-out training records in the running train loop.
    del public_train, public_val
    seed_all(train_config.seed)
    model = MultiScaleLocalModel.from_local_pretrained(pretrained, model_config)
    write_json(output / 'initialization.json', verify_pretrained(model, pretrained))
    model.to('cuda:0').train()
    if any(p.dtype != torch.float32 for p in model.parameters()):
        raise TypeError('Model parameters must remain FP32')
    optimizer, groups = optimizer_for(model, train_config, config['local_lr'])
    scheduler = build_lr_scheduler(train_config, optimizer)
    tokenizer = PromptTokenizer(ROOT / 'data/bpe_simple_vocab_16e6.txt.gz')
    loader, gallery, queries = fold_loaders(train, heldout_val, tokenizer, train_config)
    if loader.sampler.counts != __import__('collections').Counter(r.attributes for r in train.images):
        raise AssertionError('Sampler depends on data outside permitted training rows')
    config.update(heldout_domain=args.heldout_domain, data_root=str(Path(args.data_root).resolve()),
                  pretrained=str(pretrained), output=str(output),
                  steps_per_epoch=len(loader), sampling=loader.sampler.metadata(),
                  model_structure='unchanged MultiScale 4/8/12 ViT-B/16',
                  scheduler_step_unit='completed_epoch',
                  parameter_groups={g:sum(p.numel() for _,p in items) for g,items in groups.items()},
                  container=socket.gethostname(), pid=os.getpid(),
                  gpu=torch.cuda.get_device_name(0), cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'))
    write_json(output / 'config.json', config)
    history=[]; best=None; global_step=0
    status={'phase':'initialized','heldout_domain':args.heldout_domain,'completed_epochs':0}
    write_json(output / 'status.json', status)
    try:
        with (output / 'epoch_metrics.csv').open('x', newline='') as stream:
            writer=csv.writer(stream)
            writer.writerow(['heldout_domain','epoch','method','fusion_weight',*METRICS,
                             'global_step','best_epoch','best_updated','completed_kst'])
            for epoch in range(1, train_config.num_epoch + 1):
                model.train(); loader.sampler.set_epoch(epoch)
                loader.generator.manual_seed(train_config.seed + epoch - 1)
                n=0; started=time.monotonic()
                totals={k:0. for k in ('sdm_loss','map_loss','attr_bce','attr_loss','map_acc','loss')}
                for batch_number,batch in enumerate(loader,1):
                    losses, gradients = update(model,batch,optimizer,groups,
                        check_grad=batch_number <= 3 or batch_number % 100 == 0)
                    global_step+=1; count=len(batch['images']); n+=count
                    for k in totals: totals[k]+=losses[k]*count
                    if batch_number<=3 or batch_number%train_config.log_period==0 or batch_number==len(loader):
                        status.update(phase='training',current_epoch=epoch,batch=batch_number,
                            batches_total=len(loader),global_step=global_step,samples=n,
                            losses={k:v/n for k,v in totals.items()},
                            updated_kst=datetime.now(KST).isoformat())
                        write_json(output/'status.json',status)
                        log('LODO %s Epoch %d/%d batch %d/%d samples %d' %
                            (args.heldout_domain,epoch,train_config.num_epoch,batch_number,len(loader),n))
                if n != len(train.images): raise AssertionError('Epoch train draw count mismatch')
                optimizer.zero_grad(set_to_none=True)
                status['phase']='heldout_validation'; write_json(output/'status.json',status)
                validation=evaluate_local(model,gallery,queries,output/('validation_epoch_%03d'%epoch),set(train.queries))
                # Same epoch scheduler timing as actual FullTrain source.
                scheduler.step()
                record={'heldout_domain':args.heldout_domain,'epoch':epoch,'validation':validation,
                        'global_step':global_step,'training_samples':n,
                        'mean_losses':{k:v/n for k,v in totals.items()},'epoch_seconds':time.monotonic()-started}
                record,best=save_epoch_and_select_best(output,model,record,audit,asdict(train_config))
                history.append(record)
                write_json(output/'metrics.json',{'heldout_domain':args.heldout_domain,
                    'metric_scale':'fractions [0,1]', 'epochs':history, 'best':best,
                    'target_epochs':train_config.num_epoch, 'completed_epochs':epoch})
                for method,values in validation['methods'].items():
                    writer.writerow([args.heldout_domain,epoch,method,method_weight(method,validation),
                        *[values[k]*100 for k in METRICS],global_step,best['epoch'],
                        int(record['best_updated']),validation['completed_kst']])
                stream.flush()
                status.update(phase='epoch_complete',completed_epochs=epoch,best_epoch=best['epoch'],
                              best_mADM=best['metrics']['mADM'],best_fusion_weight=best['fusion_weight'])
                write_json(output/'status.json',status)
            status['phase']='complete'; write_json(output/'status.json',status)
    except Exception as error:
        status.update(phase='failed',error=repr(error)); write_json(output/'status.json',status)
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--heldout-domain',required=True,choices=tuple(DOMAINS))
    parser.add_argument('--config',default=str(ROOT/'configs/fulltrain_lodo.json'))
    parser.add_argument('--data-root',default=str(ROOT.parent/'data'))
    parser.add_argument('--pretrained',default=str(ROOT.parent/'weights/ViT-B-16.pt'))
    parser.add_argument('--output',help='Fresh run directory; defaults to unique experiments/LODO-* run')
    parser.add_argument('--dry-run',action='store_true',help='Read-only split audit/config; no training/model/GPU initialization')
    run(parser.parse_args())
