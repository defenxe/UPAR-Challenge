"""QB SDM+MAP with one additional supervised local attribute branch."""
from dataclasses import dataclass
import inspect
import math
import torch
import torch.nn.functional as F
from model.clip_model import CLIP
from model.objectives import compute_attribute_sdm, compute_map
from .checkpoint import check_checkpoint, checkpoint_dict
from .config import ModelConfig
from .model import UPARModel
from .local_branch import LocalAttributeBranch
from .masking import IGNORE_INDEX

ARCHITECTURE = 'qb-global-local-attribute-v1'


@dataclass
class LocalModelConfig(ModelConfig):
    attr_loss_weight: float = 0.5
    local_heads: int = 8
    fusion_weight: float = 0.0
    attribute_score: str = 'nll'


def load_artifact(path):
    # Trusted local experiment artifacts; compatible with the lab's PyTorch 1.12.
    options = {'map_location': 'cpu'}
    if 'weights_only' in inspect.signature(torch.load).parameters:
        options['weights_only'] = True
    return torch.load(path, **options)


class GlobalLocalModel(UPARModel):
    def __init__(self, clip_model, clip_config, config=None, with_map=True):
        config = config or LocalModelConfig()
        if not math.isfinite(config.attr_loss_weight) or config.attr_loss_weight < 0:
            raise ValueError('Attribute loss weight must be finite and nonnegative')
        if not math.isfinite(config.fusion_weight) or not 0 <= config.fusion_weight <= 1:
            raise ValueError('Fusion weight must be in [0,1]')
        if config.attribute_score not in ('nll', 'agreement'):
            raise ValueError('Unknown attribute score')
        super().__init__(clip_model, clip_config, config, with_map)
        with torch.random.fork_rng(devices=[]):
            self.local_branch = LocalAttributeBranch(self.embed_dim, config.local_heads)

    @classmethod
    def from_qb_checkpoint(cls, checkpoint, config=None):
        check_checkpoint(checkpoint)
        state = checkpoint['model']
        if not any(key.startswith('mlm_head.') for key in state) or not any(key.startswith('cross_modal_transformer.') for key in state):
            raise ValueError('QB initialization requires Encoder AND trained MAP weights; encoder export is insufficient')
        if any(key.startswith('local_branch.') for key in state):
            raise ValueError('Use from_checkpoint_dict for a local-model checkpoint')
        config = config or LocalModelConfig(**checkpoint['model_config'])
        clip_config = dict(checkpoint['clip_config'])
        clip_config['image_resolution'] = tuple(clip_config['image_resolution'])
        model = cls(CLIP(**clip_config), clip_config, config, with_map=True).float()
        report = model.load_state_dict(state, strict=False)
        expected = {k for k in model.state_dict() if k.startswith('local_branch.')}
        if set(report.missing_keys) != expected or report.unexpected_keys:
            raise ValueError('QB weight mismatch beyond newly initialized Local Branch: ' + str(report))
        if not all(torch.equal(model.state_dict()[k], v) for k, v in state.items()):
            raise ValueError('QB copied weights differ from source')
        model.initialization_report = {'copied_keys': len(state), 'missing_new_local_keys': report.missing_keys,
                                       'unexpected_keys': report.unexpected_keys,
                                       'all_existing_weights_identical': True}
        return model

    @classmethod
    def from_checkpoint_dict(cls, checkpoint, with_map=False):
        check_checkpoint(checkpoint)
        if checkpoint.get('architecture') != ARCHITECTURE:
            raise ValueError('Not a Global+Local checkpoint')
        config = LocalModelConfig(**checkpoint['model_config'])
        clip_config = dict(checkpoint['clip_config'])
        clip_config['image_resolution'] = tuple(clip_config['image_resolution'])
        model = cls(CLIP(**clip_config), clip_config, config, with_map)
        state = checkpoint['model']
        if not with_map:
            state = {k: v for k, v in state.items() if k.startswith(('base_model.', 'local_branch.')) or k == 'logit_scale'}
        model.load_state_dict(state, strict=True)
        return model.float()

    def local_from_tokens(self, image_tokens):
        if image_tokens.ndim != 3 or image_tokens.shape[1:] != (193, 512):
            raise ValueError('Expected CLIP [B,193,512] with CLS at position zero')
        return self.local_branch(image_tokens[:, 1:, :])[0]

    def encode_image_and_attributes(self, images):
        tokens = self.base_model.encode_image(images)
        return tokens[:, 0, :].float(), self.local_from_tokens(tokens)

    def forward(self, batch):
        if not self.training or not self.with_map:
            raise RuntimeError('Training forward requires train mode and MAP modules')
        images, token_ids = batch['images'], batch['caption_ids']
        image_tokens, text_tokens = self.base_model(images, token_ids)
        image_global = image_tokens[:, 0, :].float()
        eos_positions = token_ids.eq(49407).long().argmax(dim=1)
        text_global = text_tokens[torch.arange(len(token_ids), device=token_ids.device), eos_positions].float()
        # Exact existing QB global losses and MAP architecture.
        sdm_loss = compute_attribute_sdm(image_global, text_global, batch['attributes'], self.logit_scale)
        masked_tokens = self.base_model.encode_text(batch['map_ids'])
        fused = self.cross_former(masked_tokens, image_tokens, image_tokens)
        selected = batch['map_labels'].ne(IGNORE_INDEX)
        scores = self.mlm_head(fused[selected]).float()
        labels = batch['map_labels'][selected]
        map_loss = compute_map(scores, labels) * self.config.map_loss_weight
        accuracy = scores.argmax(-1).eq(labels).float().mean() if labels.numel() else scores.sum() * 0
        logits = self.local_from_tokens(image_tokens)
        attributes = batch['attributes']
        if attributes.shape != logits.shape or not ((attributes == 0) | (attributes == 1)).all():
            raise ValueError('Attribute BCE labels must be binary [B,40] in official order')
        bce = F.binary_cross_entropy_with_logits(logits.float(), attributes.float())
        return {'sdm_loss': sdm_loss, 'map_loss': map_loss, 'attr_bce': bce,
                'attr_loss': self.config.attr_loss_weight * bce, 'attribute_logits': logits,
                'map_acc': accuracy, 'map_tokens': selected.sum(),
                'temperature': self.logit_scale.reciprocal()}


def local_checkpoint_dict(model, **training_state):
    result = checkpoint_dict(model)
    result['architecture'] = ARCHITECTURE
    result.update(training_state)
    return result


def save_local_checkpoint(path, model, **training_state):
    from pathlib import Path
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    torch.save(local_checkpoint_dict(model, **training_state), temporary)
    temporary.replace(path)


def parameter_groups(model):
    blocks = len(model.base_model.visual.transformer.resblocks)
    image_prefixes = tuple('base_model.visual.transformer.resblocks.%d.' % i for i in range(blocks-2, blocks))
    result = {'local': [], 'image': [], 'map': []}
    for name, p in model.named_parameters():
        if name.startswith('local_branch.'):
            result['local'].append((name, p))
        elif name.startswith(image_prefixes) or name.startswith('base_model.visual.ln_post.') or name == 'base_model.visual.proj':
            result['image'].append((name, p))
        elif not name.startswith('base_model.'):
            result['map'].append((name, p))
    return result


def set_stage(model, stage):
    if stage not in ('head_only', 'partial_finetune'):
        raise ValueError('Unknown training stage')
    model.requires_grad_(False)
    groups = parameter_groups(model)
    for group in (('local',) if stage == 'head_only' else ('local', 'image', 'map')):
        for _, parameter in groups[group]:
            parameter.requires_grad_(True)
    return {group: sum(p.numel() for _, p in items if p.requires_grad) for group, items in groups.items()}
