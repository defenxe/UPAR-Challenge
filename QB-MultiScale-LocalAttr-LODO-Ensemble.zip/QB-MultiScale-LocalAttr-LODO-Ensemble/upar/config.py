"""Initial DESIGN.md settings and unchanged IRRA Adam/scheduler defaults."""
from dataclasses import dataclass


@dataclass
class ModelConfig:
    img_size: tuple = (384, 128)
    stride_size: int = 16
    text_length: int = 77
    vocab_size: int = 49408
    temperature: float = 0.02
    cmt_depth: int = 4
    map_loss_weight: float = 1.0


@dataclass
class TrainConfig:
    batch_size: int = 32
    test_batch_size: int = 128
    num_workers: int = 8
    num_epoch: int = 60
    lr: float = 1e-5
    weight_decay: float = 4e-5
    alpha: float = 0.9
    beta: float = 0.999
    adam_eps: float = 1e-3
    milestones: tuple = (20, 50)
    gamma: float = 0.1
    warmup_factor: float = 0.1
    warmup_epochs: int = 5
    warmup_method: str = 'linear'
    lrscheduler: str = 'cosine'
    target_lr: float = 0.0
    power: float = 0.9
    seed: int = 1
    log_period: int = 100
    eval_query_batch_size: int = 32
