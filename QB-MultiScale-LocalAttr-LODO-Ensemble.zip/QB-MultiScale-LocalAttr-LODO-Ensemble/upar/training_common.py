"""Fresh CLIP initialization and 60 epochs of joint QB Global + Local training."""
import argparse
import csv
import hashlib
import json
import math
import random
import time
import traceback
import sys
import os
import shutil
import socket
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

from model.clip_model import resize_pos_embed
from solver import build_lr_scheduler
from .config import TrainConfig
from .local_model import load_artifact
from .multiscale_model import MultiScaleLocalModel as GlobalLocalModel, MultiScaleModelConfig as LocalModelConfig, save_multiscale_checkpoint as save_local_checkpoint
from .local_validation import evaluate_local, KST, log, METRICS
from .reproducibility import capture_rng, restore_rng
from .tokenizer import PromptTokenizer
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
RUN_TYPE = 'clip-pretrained-joint-qb-multiscale-4-8-12-60epoch'
REFERENCE_FULL_TRAIN_FINGERPRINT = '9b857234d8c640e915154fb1e299ec366cadaa2f2435f18fc78970aaac3fbe74'


class Tee:
    def __init__(self, console, path):
        self.console, self.file = console, Path(path).open('a', buffering=1)

    def write(self, text):
        self.console.write(text)
        self.file.write(text)

    def flush(self):
        self.console.flush()
        self.file.flush()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False))
    temporary.replace(path)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 ** 2), b''):
            h.update(chunk)
    return h.hexdigest()


def seed_all(value):
    random.seed(value)
    np.random.seed(value)
    torch.manual_seed(value)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(value)


def joint_groups(model):
    """All image/text/MAP/local parameters are active from the first update."""
    model.requires_grad_(True)
    groups = {name: [] for name in ('image', 'text', 'map', 'local', 'multiscale')}
    for name, parameter in model.named_parameters():
        group = ('multiscale' if name.startswith('multiscale.') else
                 'local' if name.startswith('local_branch.') else
                 'image' if name.startswith('base_model.visual.') else
                 'text' if name.startswith('base_model.') else 'map')
        groups[group].append((name, parameter))
    ids = [id(p) for items in groups.values() for _, p in items]
    if len(ids) != len(set(ids)) or len(ids) != len(list(model.parameters())):
        raise AssertionError('Missing or duplicated optimizer parameter')
    if any(not items for items in groups.values()):
        raise AssertionError('Empty training module group')
    return groups


def optimizer_for(model, train_config, local_lr):
    groups = joint_groups(model)
    optimizer = torch.optim.Adam(
        [{'params': [p for _, p in items], 'name': name,
          'lr': local_lr if name in ('local', 'multiscale') else train_config.lr}
         for name, items in groups.items()],
        betas=(train_config.alpha, train_config.beta), eps=train_config.adam_eps,
        weight_decay=train_config.weight_decay)
    return optimizer, groups


def verify_pretrained(model, path):
    """Compare every backbone key against the raw foundation file, on CPU."""
    raw = torch.jit.load(str(path), map_location='cpu').state_dict()
    state = model.base_model.state_dict()
    missing = set(state) - set(raw)
    if missing:
        raise AssertionError('Missing CLIP foundation keys: ' + str(sorted(missing)))
    mismatches = []
    for name, actual in state.items():
        expected = raw[name]
        if name == 'visual.positional_embedding' and expected.shape != actual.shape:
            expected = resize_pos_embed(expected, actual, model.base_model.visual.num_y,
                                        model.base_model.visual.num_x)
        if not torch.equal(actual.cpu(), expected.to(dtype=actual.dtype)):
            mismatches.append(name)
    if mismatches:
        raise AssertionError('CLIP foundation mismatch: ' + str(mismatches))
    return {'source': str(Path(path).resolve()), 'source_sha256': digest(path),
            'backbone_keys_verified': len(state), 'missing_keys': [], 'mismatched_keys': [],
            'ignored_foundation_metadata_keys': sorted(set(raw) - set(state)),
            'positional_embedding': 'same QB bilinear resize, 14x14 to 24x8',
            'MAP_initialization': 'fresh IRRA constructor, same seed and initialization as QB',
            'local_initialization': 'fresh LocalAttributeBranch; no trained checkpoint used',
            'multiscale_initialization': 'fresh LayerNorm/Linear768->512 for blocks4/8 and log(.2,.2,.6) fusion',
            'optimizer_scheduler_initialization': 'fresh; no source optimizer/scheduler loaded'}


def gradient_report(model, groups):
    norms = {}
    for group, items in groups.items():
        squared = torch.zeros((), device=next(model.parameters()).device)
        for name, p in items:
            if p.grad is None or not torch.isfinite(p.grad).all():
                raise FloatingPointError('Missing/nonfinite gradient: ' + name)
            squared += p.grad.detach().square().sum()
        norms[group] = float(squared.sqrt())
        if not math.isfinite(norms[group]) or norms[group] <= 0:
            raise FloatingPointError('No finite nonzero gradient in ' + group)
    return norms


def update(model, batch, optimizer, groups, check_grad=False):
    device = next(model.parameters()).device
    batch = {name: value.to(device) for name, value in batch.items()}
    optimizer.zero_grad(set_to_none=True)
    result = model(batch)
    loss = result['sdm_loss'] + result['map_loss'] + result['attr_loss']
    if not torch.isfinite(loss):
        raise FloatingPointError('Nonfinite SDM+MAP+0.5*BCE loss')
    loss.backward()
    gradients = gradient_report(model, groups) if check_grad else None
    optimizer.step()
    losses = {name: float(result[name].detach()) for name in
              ('sdm_loss', 'map_loss', 'attr_bce', 'attr_loss', 'map_acc')}
    losses['loss'] = float(loss.detach())
    return losses, gradients


