"""Real ViT-B/16 FullTrain checkpoint + single synthetic CPU Adam update."""
import gc
import json
from pathlib import Path
import sys
import tempfile
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from PIL import Image
import torch
from upar.multiscale_model import MultiScaleLocalModel,MultiScaleModelConfig
from upar.training_common import verify_pretrained,seed_all,optimizer_for,update
from upar.config import TrainConfig
from upar.lodo_results import save_epoch_and_select_best
from upar.local_validation import METRICS
from upar.ensemble import load_best_artifact,EnsembleRetrievalEngine,Gallery
from upar.prompts import encode_query
from upar.tokenizer import PromptTokenizer
from solver import build_lr_scheduler

ROOT=Path(__file__).resolve().parents[1]

def main():
    torch.set_num_threads(2);seed_all(1);started=time.monotonic()
    pretrained=ROOT.parent/'weights/ViT-B-16.pt'
    model=MultiScaleLocalModel.from_local_pretrained(pretrained,MultiScaleModelConfig())
    verified=verify_pretrained(model,pretrained)
    tokenizer=PromptTokenizer()
    attrs=torch.zeros(2,40,dtype=torch.long);attrs[:,1]=1;attrs[:,3]=1;attrs[1,1]=0;attrs[1,0]=1
    ids=torch.tensor([encode_query(v.tolist(),tokenizer).token_ids for v in attrs])
    map_ids=ids.clone();labels=torch.full_like(ids,-100)
    # Select one non-special attribute-associated token per sample.
    for i in range(2):
        prompt=encode_query(attrs[i].tolist(),tokenizer)
        position=next(j for j,allowed in enumerate(prompt.attribute_token_mask) if allowed)
        labels[i,position]=ids[i,position];map_ids[i,position]=tokenizer.mask_id
    batch={'images':torch.randn(2,3,384,128),'caption_ids':ids,'attributes':attrs,
           'map_ids':map_ids,'map_labels':labels}
    model.train();optimizer,groups=optimizer_for(model,TrainConfig(),1e-4)
    scheduler=build_lr_scheduler(TrainConfig(),optimizer)
    lr_before={g['name']:g['lr'] for g in optimizer.param_groups}
    before=model.local_branch.attribute_bias.detach().clone()
    losses,norms=update(model,batch,optimizer,groups,check_grad=True)
    assert not torch.equal(before,model.local_branch.attribute_bias)
    assert scheduler.last_epoch==0
    # Preserve the source's scheduler policy: once after epoch validation, not per batch.
    scheduler.step();assert scheduler.last_epoch==1
    assert all(p.dtype==torch.float32 and p.grad.dtype==torch.float32 and torch.isfinite(p.grad).all() for p in model.parameters())
    optimizer.zero_grad(set_to_none=True);del optimizer;gc.collect()
    print('Real FP32 CPU Adam update passed; checking checkpoint/inference',flush=True)
    audit=json.loads((ROOT/'reports/real_split_audit.json').read_text())['market']
    dummy={m:.5 for m in METRICS}
    row={'heldout_domain':'market','epoch':2,'validation':{'best_weights':{'nll':.4},
         'methods':{'Global-only':dummy,'Global+NLL':dummy},'synthetic_test_only':True}}
    with tempfile.TemporaryDirectory(prefix='lodo_real_model_') as temp:
        root=Path(temp)
        _,best=save_epoch_and_select_best(root,model,row,audit,{})
        artifact,metadata,state_sha=load_best_artifact(root/'best.pth','market')
        inferred=MultiScaleLocalModel.from_checkpoint_dict(artifact,with_map=False).eval()
        for key,value in inferred.state_dict().items():assert torch.equal(value,model.state_dict()[key])
        # Execute the actual sequential scoring implementation for this one real model.
        gallery=[]
        for i,color in enumerate([(30,70,110),(160,30,20)]):
            path=root/('gallery%d.png'%i);Image.new('RGB',(32,64),color).save(str(path))
            gallery.append({'image':'gallery%d'%i,'image_path':str(path)})
        sample={'queries':attrs.tolist(),'gallery':gallery}
        engine=object.__new__(EnsembleRetrievalEngine)
        engine.device=torch.device('cpu');engine.batch_size=2;engine.query_chunk=1;engine.tokenizer=tokenizer
        scores=engine._score_model(inferred,sample,root/'real_fused.npy')
        assert scores.shape==(2,2) and np.isfinite(scores).all()
        assert inferred.config.fusion_weight==.4
        with torch.no_grad():
            tokens,intermediate=inferred.image_tokens_and_scales(batch['images'][:1])
            assert tokens.shape==(1,193,512)
            assert set(intermediate)=={4,8} and all(x.shape==(1,192,768) for x in intermediate.values())
        checkpoint_bytes=(root/'best.pth').stat().st_size
    value={'passed':True,'device':'cpu','synthetic_only':True,'pretrained_verification':verified,
           'real_FP32_Adam_backward_and_update':'PASS','losses':losses,'gradient_norms':norms,
           'initial_lrs':lr_before,'scheduler_epoch_steps':1,
           'existing_checkpoint_format_reload':'PASS','inference_state_equal_to_saved_model':True,
           'best_selected_epoch':2,'fusion_weight_test':.4,'fusion_scores_shape':[2,2],
           'checkpoint_bytes':checkpoint_bytes,'temporary_checkpoint_deleted':True,
           'elapsed_seconds':time.monotonic()-started,
           'not_tested':['full training','real trained LODO bests','GPU memory/performance','full common validation','Codabench runtime']}
    (ROOT/'reports/real_model_cpu_tests.json').write_text(json.dumps(value,indent=2));print(json.dumps(value,indent=2),flush=True)

if __name__=='__main__':main()
