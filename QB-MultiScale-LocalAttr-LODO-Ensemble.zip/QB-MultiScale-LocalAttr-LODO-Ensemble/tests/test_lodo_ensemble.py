"""CPU-only unit tests: data isolation, best links, macros, ID alignment and API."""
import copy
from dataclasses import replace
import json
from pathlib import Path
import sys
import tempfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from PIL import Image
import torch
from torch import nn
from upar.attributes import ATTRIBUTE_NAMES
from upar.data import UPARSplit,ImageRecord
from upar.lodo_data import DOMAINS,fold_splits,audit_fold,fold_loaders,domain
from upar.lodo_results import FOLDS,save_epoch_and_select_best,aggregate_histories
from upar.ensemble import EnsembleRetrievalEngine,average_score_bundles,canonical_sample,load_best_artifact,evaluate_score_matrix
from upar.local_scoring import stable_rank,fuse
from upar.local_validation import METRICS,evaluate_local
from upar.multiscale_model import MultiScaleModelConfig,ARCHITECTURE
from upar.config import TrainConfig
from upar.tokenizer import PromptTokenizer
from upar.prompts import PROMPT_VERSION
from upar.training_common import digest

ROOT=Path(__file__).resolve().parents[1]

class Tiny(nn.Module):
    """Small state uses the existing checkpoint schema, with a test-only factory."""
    def __init__(self,marker):
        super().__init__()
        self.base_model=nn.Linear(1,1,bias=False)
        with torch.no_grad(): self.base_model.weight.fill_(marker)
        self.multiscale=nn.Module(); self.multiscale.fusion_logits=nn.Parameter(torch.tensor([.2,.2,.6]).log())
        self.config=MultiScaleModelConfig(); self.clip_config={'test_only':True}
    def encode_text(self,ids):
        return torch.stack((ids.float().sum(1)/100000.,ids.float().mean(1)/10000.,torch.ones(len(ids))),1)
    def encode_image_and_attributes(self,images):
        x=images.mean((2,3)); marker=self.base_model.weight.reshape(())
        logits=x[:,0:1]*marker*torch.linspace(-2,2,40)[None,:]+marker*.1
        return x+marker*torch.tensor([.1,.2,.3]),logits


def val_result(value,weight=.4):
    return {'best_weights':{'nll':weight,'agreement':weight},
            'methods':{'Global-only':{m:value-.05 for m in METRICS},
                       'Global+NLL':{m:value for m in METRICS}},
            'synthetic_test_only':True}


def record(fold,epoch,value,weight=.4):
    return {'heldout_domain':fold,'epoch':epoch,'validation':val_result(value,weight)}


def tiny_factory(artifact):
    model=Tiny(0.)
    model.config=MultiScaleModelConfig(**artifact['model_config'])
    model.load_state_dict(artifact['model'],strict=True)
    return model


class ProtocolModel(nn.Module):
    def __init__(self): super().__init__(); self.marker=nn.Parameter(torch.zeros(()))
    def encode_text(self,tokens): return tokens.float()
    def encode_image_and_attributes(self,x): return x[:,:3],x[:,3:]


def main():
    torch.set_num_threads(2); torch.manual_seed(1)
    with tempfile.TemporaryDirectory(prefix='lodo_ensemble_test_') as temporary:
        root=Path(temporary)
        a=tuple([0]*40); b=tuple([1]+[0]*39); c=tuple([0,1]+[0]*38)
        train_rows=[];val_rows=[]
        for index,prefix in enumerate(DOMAINS.values()):
            for j,attrs in enumerate([a,(a,b,c)[index]]):
                path=root/prefix/('train%d.png'%j);path.parent.mkdir(parents=True,exist_ok=True);Image.new('RGB',(8,12),(40,70,90)).save(str(path))
                train_rows.append(ImageRecord(prefix+'/'+path.name,path,attrs,[a,b,c].index(attrs)))
            path=root/prefix/'val.png';Image.new('RGB',(8,12)).save(str(path))
            val_rows.append(ImageRecord(prefix+'/'+path.name,path,(a,b,c)[index],index))
        train=UPARSplit('train',tuple(train_rows),(a,b,c));val=UPARSplit('val',tuple(val_rows),(a,b,c))
        audits={}
        for fold in FOLDS:
            filtered,heldout=fold_splits(root,fold,(train,val))
            audit=audit_fold(fold,filtered,heldout,train,val)
            assert len(filtered.images)==4 and len(heldout.images)==1
            assert all(domain(r)!=DOMAINS[fold] for r in filtered.images)
            config=TrainConfig(batch_size=2,test_batch_size=1,num_workers=0)
            loader,gallery,queries=fold_loaders(filtered,heldout,PromptTokenizer(),config)
            assert loader.dataset.split is filtered and loader.sampler.num_samples==4
            assert sum(loader.sampler.counts.values())==4
            batch=next(iter(loader));assert batch['images'].dtype==torch.float32 and batch['images'].shape==(2,3,384,128)
            assert audit['heldout_in_sampler']==0 and audit['checks_passed']
            audits[fold]=audit
        histories={fold:[record(fold,1,.4),record(fold,2,.5),record(fold,3,.45)] for fold in FOLDS}
        histories['market'][0]['validation']=val_result(.6)
        histories['peta'][2]['validation']=val_result(.7)
        summary=aggregate_histories(histories)
        assert summary['common_epochs']==[1,2,3]
        assert summary['independent_best_macro']['best_epochs']=={'market':1,'peta':3,'pa100k':2}
        assert abs(summary['independent_best_macro']['methods']['Global+NLL']['mADM']-(.6+.7+.5)/3)<1e-12
        assert summary['same_epoch_macro'][1]['methods']['Global+NLL']['mADM']==.5
        incomplete=copy.deepcopy(histories);incomplete['market'].pop()
        assert aggregate_histories(incomplete)['common_epochs']==[1,2]
        duplicate=copy.deepcopy(histories);duplicate['market'].append(duplicate['market'][0])
        try: aggregate_histories(duplicate)
        except ValueError: pass
        else: raise AssertionError('Duplicate epoch must fail')
        paths={};weights={}
        for index,fold in enumerate(FOLDS):
            directory=root/fold;directory.mkdir();model=Tiny(index+1.)
            for epoch,value in [(1,.4),(2,.6),(3,.5),(4,.6)]:
                with torch.no_grad():model.base_model.weight.fill_(index+epoch)
                epoch_record=record(fold,epoch,value,.2*(index+1) if epoch<=2 else .9 if epoch==3 else .1)
                if epoch==3: epoch_record['validation']['methods']['Global+NLL']['mAP']=.95
                row,best=save_epoch_and_select_best(directory,model,epoch_record,audits[fold],{})
                if epoch>=2: assert best['metrics']['mAP']==.6 and best['fusion_weight']==.2*(index+1)
                assert best['epoch']==(1 if epoch==1 else 2)
                assert row['best_updated']==(epoch in (1,2))
                assert (directory/'best.pth').resolve().name==('epoch_001.pth' if epoch==1 else 'epoch_002.pth')
            assert digest(directory/'best.pth')==digest(directory/'epoch_002.pth')
            try: load_best_artifact(directory/'epoch_003.pth',fold)
            except ValueError: pass
            else: raise AssertionError('Non-best Epoch input must fail')
            artifact,metadata,state_hash=load_best_artifact(directory/'best.pth',fold)
            assert artifact['epoch']==2 and artifact['model']['base_model.weight'].item()==index+2
            paths[fold]=directory/'best.pth';weights[fold]=metadata['fusion_weight']
        qids=['q0','q1'];gids=['image0','image1','image2'];vectors=np.asarray([a,b])
        base=np.array([[1.,2.,3.],[3.,2.,1.]])
        bundles=[]
        for k in range(3):
            rows=np.array([1,0]) if k else np.arange(2)
            columns=np.array([2,0,1]) if k else np.arange(3)
            path=root/('bundle%d.npy'%k);np.save(str(path),(base+k)[rows][:,columns])
            bundles.append({'path':path,'query_ids':[qids[i] for i in rows],
                            'gallery_ids':[gids[i] for i in columns],'query_vectors':vectors[rows].tolist()})
        average=average_score_bundles(bundles,qids,gids,root/'mean.npy',vectors)
        np.testing.assert_allclose(average,base+1,rtol=0,atol=0)
        bad=copy.deepcopy(bundles);bad[2]['gallery_ids'][0]='different_image'
        try: average_score_bundles(bad,qids,gids,root/'bad.npy',vectors)
        except ValueError: pass
        else: raise AssertionError('Different evaluation galleries must fail')
        bad=copy.deepcopy(bundles);np.save(str(bad[2]['path']),np.full((2,3),np.nan))
        try: average_score_bundles(bad,qids,gids,root/'nonfinite.npy',vectors)
        except ValueError: pass
        else: raise AssertionError('NaN scores must fail')
        gallery_items=[]
        for i,color in enumerate([(30,70,110),(160,30,20),(90,130,50)]):
            path=root/('g%d.png'%i);Image.new('RGB',(8,12),color).save(str(path))
            gallery_items.append({'index':i,'image':'image%d'%i,'image_path':str(path)})
        sample={'attribute_names':list(ATTRIBUTE_NAMES),'queries':[a,b],'query_ids':qids,
                'gallery':gallery_items,'evaluation_name':'synthetic CPU only'}
        engine=EnsembleRetrievalEngine(paths,device='cpu',batch_size=2,model_factory=tiny_factory)
        result=engine.rank_gallery(sample,root/'ensemble')
        matrices=[np.load(str(root/'ensemble'/(f+'_fused_scores.npy'))) for f in FOLDS]
        np.testing.assert_allclose(result['similarities'],sum(matrices)/3,rtol=0,atol=0)
        assert result['similarities'].shape==(2,3) and np.isfinite(result['similarities']).all()
        rankings=stable_rank(result['similarities'])
        assert all(np.array_equal(np.sort(row),np.arange(3)) for row in rankings)
        provenance=json.loads((root/'ensemble/ensemble_metadata.json').read_text())
        assert len({v['retrieval_state_sha256'] for v in provenance['models'].values()})==3
        assert {f:v['fusion_weight'] for f,v in provenance['models'].items()}==weights
        # Compare model-by-model scores with the exact source fusion function.
        from upar.ensemble import Gallery
        images=torch.stack([Gallery(gallery_items)[i] for i in range(3)])
        from upar.prompts import encode_query
        tokenizer=PromptTokenizer();tokens=torch.tensor([encode_query(v,tokenizer).token_ids for v in [a,b]])
        from upar.local_scoring import attribute_scores
        import torch.nn.functional as F
        for fold,matrix in zip(FOLDS,matrices):
            artifact,meta,_=load_best_artifact(paths[fold],fold);model=tiny_factory(artifact).eval()
            with torch.no_grad():
                image,z=model.encode_image_and_attributes(images);text=model.encode_text(tokens)
                global_score=(F.normalize(text,dim=1)@F.normalize(image,dim=1).t()).numpy()
                nll,_=attribute_scores([a,b],z)
            np.testing.assert_allclose(matrix,fuse(global_score,nll,meta['fusion_weight']),rtol=1e-6,atol=1e-6)
        # Official run.py API returns exactly the similarities key.
        import run as submission_api
        submission_api._ENGINE=engine
        api_result=submission_api.rank_gallery(sample)
        assert set(api_result)=={'similarities'} and api_result['similarities'].shape==(2,3)
        submission_api._ENGINE=None
        # Checkpoints with different metadata but identical retrieval parameters are rejected.
        clone_dir=root/'peta_clone';clone_dir.mkdir()
        clone=Tiny(2.)
        save_epoch_and_select_best(clone_dir,clone,record('peta',2,.6,.4),audits['peta'],{})
        clone_paths=dict(paths,peta=clone_dir/'best.pth')
        try: EnsembleRetrievalEngine(clone_paths,device='cpu',batch_size=2,model_factory=tiny_factory).rank_gallery(sample,root/'cloned_ensemble')
        except ValueError as error: assert 'identical retrieval weights' in str(error)
        else: raise AssertionError('Three renamed copies must not be accepted')
        metadata_path=paths['peta'].with_suffix('.json');original_meta=metadata_path.read_text()
        changed=json.loads(original_meta);changed['fusion_weight']=.99;metadata_path.write_text(json.dumps(changed))
        try: load_best_artifact(paths['peta'],'peta')
        except ValueError: pass
        else: raise AssertionError('Wrong fusion weight must fail')
        metadata_path.write_text(original_meta)
        reversed_sample=dict(sample,attribute_names=list(reversed(ATTRIBUTE_NAMES)),queries=[list(reversed(a)),list(reversed(b))])
        assert canonical_sample(reversed_sample)['queries']==[list(a),list(b)]
        # Original held-out evaluation path computes all six metrics and selects fusion.
        q=torch.tensor([a,b]);ga=q[torch.tensor([0,1,0,1,0,1])]
        features=torch.tensor([[1.,0.,0.],[0.,1.,0.],[.8,.2,0.],[.2,.8,0.],[.6,.4,0.],[.4,.6,0.]])
        logits=torch.full((6,40),-2.);logits[:,0]=torch.tensor([-3.,3.,-1.,1.,-.1,.1])
        validation=evaluate_local(ProtocolModel(),[(ga,torch.cat((features,logits),1))],
                                  [(q,torch.tensor([[1.,0.,0.],[0.,1.,0.]]))],root/'validation',{a})
        assert validation['sweep_official_max_abs_error']<=1e-12
        score_metrics=evaluate_score_matrix(np.array([[6,1,5,2,4,3],[1,6,2,5,3,4]]),[a,b],ga)
        assert set(score_metrics)==set(METRICS) and all(np.isfinite(v) for v in score_metrics.values())
    report={'passed':True,'device':'cpu','test_only':True,'data_isolation_and_sampler':'PASS',
            'best_strict_improvement_and_tie':'PASS','best_symlink_same_weights':'PASS',
            'same_epoch_and_independent_best_macro':'PASS','id_alignment':'PASS',
            'common_query_gallery_rejection':'PASS','NaN_rejection':'PASS',
            'sequential_three_distinct_mock_weights':'PASS','model_fusion_weights':'PASS',
            'codabench_run_api':'PASS','identical_weight_rejection':'PASS','wrong_fusion_weight_rejection':'PASS','non_best_epoch_rejection':'PASS',
            'score_average_exact':'PASS','rank_permutations':'PASS','attribute_name_remap':'PASS',
            'official_validation_sweep_max_error':validation['sweep_official_max_abs_error']}
    (ROOT/'reports/unit_tests.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
