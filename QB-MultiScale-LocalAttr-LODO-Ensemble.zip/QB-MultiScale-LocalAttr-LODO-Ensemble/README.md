# QB-MultiScale-LocalAttr-LODO-Ensemble

`IRRA-QB-MultiScaleLocalAttr-FullTrain`을 기반으로 만든 독립 프로젝트입니다. 사용자 요청의 FullTrain은 실제로 이 디렉터리에 있었습니다. **Full Training 및 Codabench 제출은 실행하지 않았습니다.**

ViT-B/16, 384×128, FP32, QueryBalanced, MultiScale 4/8/12, SDM+MAP+.5BCE, LR/Adam, 5 Epoch Warm-up + Epoch Cosine, 60 Epoch, Seed 1을 원본 그대로 유지합니다. 세 모델은 모두 같은 CLIP Pretrained에서 새로 시작하며 기존 FullTrain 또는 다른 Fold의 학습 가중치로 초기화하지 않습니다.

## 실제 공식 분할

| Fold | 학습 도메인 | 학습 이미지 | 제외한 Train 이미지 | Held-out Val Gallery | Held-out Val Query |
|---|---|---:|---:|---:|---:|
| market | PETA + PA100k | 87,669 | 10,000 | 16,458 | 956 |
| peta | Market1501 + PA100k | 89,001 | 8,668 | 6,963 | 1,763 |
| pa100k | Market1501 + PETA | 18,668 | 79,001 | 9,986 | 1,479 |

공식 `annotations/task2/train`에서 Held-out 이미지 행을 제거한 다음 Training Query ID와 Vocabulary를 재생성합니다. QueryBalanced 통계 및 Epoch draw 수는 남은 Training 행에서만 계산합니다. Val은 공식 `annotations/task2/val`의 Held-out Domain Gallery와 정확한 40-bit 일치 이미지가 있는 공식 Query를 원래 순서로 사용합니다. 전처리·지표 공식·Fusion Grid는 원본을 재사용합니다.

**Held-out Val로 Fusion Weight와 Best Epoch을 선택하므로 untouched unseen-domain test 성능이 아닙니다.** 세 모델의 학습 도메인 합집합은 모든 세 도메인을 포함하므로 Ensemble 전체가 해당 도메인을 전혀 보지 않았다고 주장할 수 없습니다.

## 나중에 학습 시작

현재 작업에서는 아래 명령을 실행하지 않았습니다. 실제 환경에서 사용자가 GPU와 데이터·출력 경로를 확인한 뒤 실행하세요. 하나의 GPU만 노출해야 하며 DDP는 사용하지 않습니다. 세 명령을 같은 GPU에서 동시에 시작하지 마세요.

```bash
# Run from the cloned UPAR-Challenge repository root.
export UPAR_PROJECT_DIR="$(pwd)/QB-MultiScale-LocalAttr-LODO-Ensemble"
export UPAR_DATA_ROOT=/path/to/UPAR/data
export UPAR_PRETRAINED=/path/to/weights/ViT-B-16.pt
cd "$UPAR_PROJECT_DIR"
python -m pip install -r requirements.txt
CUDA_VISIBLE_DEVICES=0 python train.py --heldout-domain market --data-root "$UPAR_DATA_ROOT" --pretrained "$UPAR_PRETRAINED"
CUDA_VISIBLE_DEVICES=0 python train.py --heldout-domain peta --data-root "$UPAR_DATA_ROOT" --pretrained "$UPAR_PRETRAINED"
CUDA_VISIBLE_DEVICES=0 python train.py --heldout-domain pa100k --data-root "$UPAR_DATA_ROOT" --pretrained "$UPAR_PRETRAINED"
```

기본 경로는 프로젝트 상위 디렉터리의 `data/`와 `weights/ViT-B-16.pt`입니다. 저장소에는 데이터셋과 Pretrained Checkpoint를 포함하지 않으므로, 위처럼 외부 경로를 `--data-root`와 `--pretrained`로 지정하세요. 변경 가능 인자:

```bash
CUDA_VISIBLE_DEVICES=0 python train.py --heldout-domain market \
  --data-root /mnt/pvc/UPAR/data \
  --pretrained /mnt/pvc/weights/ViT-B-16.pt \
  --config configs/fulltrain_lodo.json \
  --output /mnt/pvc/experiments/LODO-Market/new_run
```

기본 출력은 `experiments/LODO-Market|LODO-PETA|LODO-PA100K/<KST timestamp_unique>/`입니다. 실행 폴더는 반드시 새 경로여야 합니다. 기존 FullTrain 폴더를 출력으로 지정하면 거부합니다.

LODO별 출력:

```text
<run>/
  train.log, config.json, split_audit.json, status.json
  epoch_001.pth ... epoch_060.pth
  epoch_001.json ... epoch_060.json
  best.pth -> epoch_<best>.pth
  best.json
  metrics.json, epoch_metrics.csv
  validation_epoch_001/ ...
```

Checkpoint는 기존 MultiScale Loader에 호환되는 dictionary(`model`, `model_config`, `clip_config`, architecture/schema 등)입니다. Optimizer/Scheduler 상태는 넣지 않습니다. Best는 **Held-out Global+NLL mADM이 엄격히 증가할 때만** 바뀌며 동률은 앞선 Epoch를 유지합니다. 상대 Symlink로 정확한 Epoch Weight를 가리키고 SHA-256·Epoch·Metric·Fusion Weight를 `best.json`에 기록합니다. 제출 포장 시 Symlink는 실제 가중치로 복사하고 `best.json`도 포함해야 합니다. 정확한 중단 재개 기능은 이번 구현에 추가하지 않았습니다.

## LODO Macro 집계

```bash
python summarize_lodo.py \
  --market-run /path/to/LODO-Market/run \
  --peta-run /path/to/LODO-PETA/run \
  --pa100k-run /path/to/LODO-PA100K/run \
  --output-dir /path/to/new_lodo_macro_report
```

- `same_epoch_macro`: 세 Fold 모두 완료한 **동일 Epoch**의 도메인별 지표를 1/3씩 평균합니다. 누락 Epoch를 보간하지 않습니다.
- `independent_best_macro`: 각 Fold의 Fusion mADM Best Epoch 지표를 평균하며 세 Best Epoch을 따로 기록합니다. 단일 Epoch 성능으로 표시하지 않습니다.
- 샘플 수 Weighted Average가 아닙니다. Global-only도 함께 기록하지만 Independent Best의 Global-only는 해당 **Fusion Best Epoch에서의** 값입니다.
- 이는 LODO Macro이며 Ensemble 평가가 아닙니다. 전체 학습이 진행 중이면 현재까지의 Best 평균입니다.

## 동일 평가 데이터에서 순차 Ensemble

```bash
CUDA_VISIBLE_DEVICES=0 python ensemble_inference.py \
  --market-ckpt /path/to/LODO-Market/run/best.pth \
  --peta-ckpt /path/to/LODO-PETA/run/best.pth \
  --pa100k-ckpt /path/to/LODO-PA100K/run/best.pth \
  --data-root /mnt/pvc/UPAR/data --eval-domain all --evaluate \
  --output-dir /path/to/new_ensemble_eval
```

`--eval-domain`은 all/market/peta/pa100k이며 항상 **세 모델 모두 같은 선택된 Val Query/Gallery**에 대해 추론합니다. 별도 Common Evaluation Manifest/실제 Retrieval 입력은 다음처럼 지정합니다.

```bash
python ensemble_inference.py \
  --market-ckpt /path/to/market/best.pth \
  --peta-ckpt /path/to/peta/best.pth \
  --pa100k-ckpt /path/to/pa100k/best.pth \
  --sample-json /path/to/common_sample.json \
  --output-dir /path/to/new_scores --device cpu --batch-size 32
```

Manifest는 기존 Codabench sample 형식(`attribute_names`, `queries`, `gallery`)을 사용합니다. Gallery는 `image`(안정적인 Image ID)와 `image_path`를 지정하세요. `query_ids`, `evaluation_name`은 선택 사항입니다. 평가하려면 `gallery_attributes: [G,40]`와 `--evaluate`를 추가합니다. `image_path`가 상대경로이면 Manifest 디렉터리를 기준으로 해석합니다. Test 정답이나 Test 서버 결과로 Weight를 조정하는 코드가 없습니다.

각 모델의 Best Epoch과 Weight를 메타데이터 및 Weight hash로 확인합니다. 서로 다른 메타데이터만 붙인 동일 Retrieval Weight 3개는 거부합니다. 모델을 순서대로 하나씩 로드하고, 기존 Global+NLL 최종 Score를 CPU `.npy`에 저장한 뒤 Image/Query ID를 정렬하여 `(S_market+S_peta+S_pa100k)/3`을 계산합니다. 모델 간 추가 정규화는 하지 않습니다. 모델별 Score 분포는 진단용으로 기록합니다. Stable Ranking과 NaN/Inf 검사를 수행합니다.

출력: 모델별 `*_fused_scores.npy`, `ensemble_scores.npy`, `ensemble_ranking.npy`, `score_ids.json`, `ensemble_metadata.json`, 선택적으로 `ensemble_metrics.json`.

## Codabench API

`run.py`의 `load_model()` / `rank_gallery(sample)`는 기존 API와 같은 `{'similarities': [Q,G]}`를 반환합니다. 행은 입력 Query, 열은 입력 Gallery 순서입니다. Attribute 이름이 다른 순서로 들어오면 Canonical 40개 순서로 재정렬합니다. 기본 Weight 위치는 `assets/market|peta|pa100k/best.pth`와 각각의 `best.json`입니다. BPE는 `data/`에 포함돼 있습니다. 실제 Submission ZIP 제작/서버 업로드 및 PyTorch 2.4.1 환경 검증은 별도 작업입니다.

## CPU 경량 테스트

```bash
CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 python tests/test_lodo_ensemble.py
CUDA_VISIBLE_DEVICES='' python train.py --heldout-domain market --data-root "$UPAR_DATA_ROOT" --dry-run
```

`reports/`의 생성 결과와 로컬 환경 보고서는 저장소에 포함하지 않습니다. 실제 학습된 LODO Best 3개, 전체 Validation, GPU 메모리/성능과 Codabench 서버 실행은 별도 환경에서 검증해야 합니다.


## Kubernetes 단일 GPU 실행

Pod와 영구 PVC를 별도로 준비하고 데이터와 ViT-B/16 Pretrained Weight를 마운트하세요. 출력 폴더는 Pod 삭제 후에도 보존되는 PVC 아래에 둡니다. `CUDA_VISIBLE_DEVICES`에 Pod에 할당된 GPU 인덱스 하나만 지정하고, 동일 GPU에서 세 Fold를 동시에 실행하지 마세요.

```bash
export UPAR_PROJECT_DIR=/workspace/UPAR-Challenge/QB-MultiScale-LocalAttr-LODO-Ensemble
export UPAR_DATA_ROOT=/mnt/pvc/UPAR/data
export UPAR_PRETRAINED=/mnt/pvc/UPAR/weights/ViT-B-16.pt
export UPAR_OUTPUT_ROOT=/mnt/pvc/UPAR/lodo-experiments
cd "$UPAR_PROJECT_DIR"
tmux new -s lodo-market
RUN_DIR="$UPAR_OUTPUT_ROOT/LODO-Market/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$UPAR_OUTPUT_ROOT/LODO-Market"
test ! -e "$RUN_DIR" || { echo "Output already exists: $RUN_DIR" >&2; exit 1; }
CUDA_VISIBLE_DEVICES=0 python train.py --heldout-domain market \
  --data-root "$UPAR_DATA_ROOT" --pretrained "$UPAR_PRETRAINED" \
  --config configs/fulltrain_lodo.json --output "$RUN_DIR"
```

Market 학습이 끝난 뒤 `tmux new -s lodo-peta`, `tmux new -s lodo-pa100k` 세션에서 같은 절차로 Fold를 하나씩 실행하고 출력 경로의 Fold 이름을 바꾸세요. 세션 복귀는 `tmux attach -t lodo-market`을 사용합니다. 이 문서는 실행 방법만 제공하며 학습을 시작하지 않습니다.
