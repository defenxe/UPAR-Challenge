"""Report domain macro (never an ensemble score)."""
import argparse
import csv
import json
from pathlib import Path
from upar.lodo_results import FOLDS, METHODS, aggregate_histories
from upar.local_validation import METRICS
from upar.training_common import write_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for fold in FOLDS: p.add_argument('--'+fold+'-run',required=True)
    p.add_argument('--output-dir',required=True)
    args=p.parse_args(); histories={}
    targets=[]
    for fold in FOLDS:
        directory=Path(getattr(args,fold+'_run')).resolve(); targets.append(directory)
        value=json.loads((directory/'metrics.json').read_text())
        if value['heldout_domain']!=fold: raise ValueError('Input run belongs to wrong held-out domain')
        if value.get('metric_scale')!='fractions [0,1]': raise ValueError('Metrics must use the training JSON fraction scale')
        histories[fold]=value['epochs']
    if len(set(targets))!=3: raise ValueError('Three independent run directories required')
    report=aggregate_histories(histories)
    output=Path(args.output_dir); output.mkdir(parents=True,exist_ok=False)
    write_json(output/'lodo_macro.json',report)
    with (output/'same_epoch_macro_percent.csv').open('x',newline='') as stream:
        writer=csv.writer(stream); writer.writerow(['epoch','method',*METRICS])
        for row in report['same_epoch_macro']:
            for method in METHODS: writer.writerow([row['epoch'],method,*[row['methods'][method][m]*100 for m in METRICS]])
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
