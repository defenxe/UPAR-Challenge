def build_dataloader(*args, **kwargs):
    # Keep optional original text-retrieval dependencies out of UPAR inference.
    from .build import build_dataloader as build
    return build(*args, **kwargs)
